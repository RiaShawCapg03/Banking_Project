package com.bdo.evolution_native.util;

import ch.qos.logback.classic.Level;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Utility class for masking sensitive information in objects.
 */
@Component
@Scope("prototype")
public class MaskUtil {

    //    private static final List<String> fieldNamesList;
//    static MessageUtil messageUtil = new MessageUtil();
    private static final Logger logger = LoggerFactory.getLogger(MaskUtil.class);

//    static {
//        // Load the initial field names from the configuration file
//        fieldNamesList = loadFieldNames();
//    }

    /**
     * Sets the logging level for unmasked values.
     *
     * @param logUnmaskedValues If true, unmasked values will be logged at INFO level; otherwise, they will be logged at DEBUG level.
     */
    private static void setLogUnmaskedValues(boolean logUnmaskedValues) {
        if (logUnmaskedValues) {
            // Log unmasked values at INFO level
            ((ch.qos.logback.classic.Logger) logger).setLevel(Level.INFO);
        } else {
            // Log unmasked values at DEBUG level
            ((ch.qos.logback.classic.Logger) logger).setLevel(Level.DEBUG);
        }
    }

    /**
     * Logs unmasked values at the appropriate level based on the current logging configuration.
     *
     * @param message The message to log.
     */
    private static void logUnmaskedValues(String message) {
        // Check the logging level and log accordingly
        if (logger.isDebugEnabled()) {
            logger.debug(message);
        } else {
            logger.info(message);
        }
    }

    /**
     * Masks the sensitive information in the given value with asterisks (*).
     *
     * @param value The sensitive information to be masked.
     * @return The masked value.
     */
    public String mask(Object value) {
        // Use a regex to replace each character with an asterisk, leaving the last two characters visible
        String regex = "\\w(?=\\w{2})";
        String replacement = "*";
        if (value != null) {
            return value.toString().replaceAll(regex, replacement);
        } else {
            return null;
        }
    }

    /**
     * Masks the sensitive information in the given value based on custom regex and replacement.
     *
     * @param value       The sensitive information to be masked.
     * @param regex       The regular expression specifying the pattern to be replaced.
     * @param replacement The replacement string for the matched pattern.
     * @return The masked value.
     */
    public String mask(Object value, String regex, String replacement) {
        // If regex is not provided, use the default regex
        regex = (regex != null && !regex.isEmpty()) ? regex : "\\w(?=\\w{2})";

        // If replacement is not provided, use the default replacement
        replacement = (replacement != null && !replacement.isEmpty()) ? replacement : "*";
        // Use a custom regex and replacement to mask sensitive information
        if (value != null) {
            return value.toString().replaceAll(regex, replacement);
        } else {
            return null;
        }
    }
    public <T> T maskObjectValues(final T object) {
        int count = 0;
        if (Objects.isNull(object)) {
            return null;
        }
        setLogUnmaskedValues(true);
        // Log before masking
        logUnmaskedValues("Before Masking: " + object.toString());
        T maskedObject = maskObject(object, "\\w(?=\\w{2})", "#", count);
        // Log after masking
        logUnmaskedValues("After Masking: " + maskedObject.toString());
        return maskedObject;
    }

    /**
     * Masks the sensitive information in the fields of an object recursively.
     *
     * @param object      The object whose fields need to be masked.
     * @param regex       The regular expression specifying the pattern to be replaced.
     * @param replacement The replacement string for the matched pattern.
     * @param <T>         The type of the object.
     * @return The object with masked sensitive information.
     */
    public <T> T maskObjectValues(final T object, String regex, String replacement) {
        int count = 0;
        if (Objects.isNull(object)) {
            return null;
        }
        setLogUnmaskedValues(true);
        // Log before masking
        logUnmaskedValues("Before Masking: " + object.toString());
        T maskedObject = maskObject(object, regex, replacement, count);
        // Log after masking
        logUnmaskedValues("After Masking: " + maskedObject.toString());
        return maskedObject;
    }

    /**
     * Masks the sensitive information in the fields of an object recursively.
     *
     * @param object          The object whose fields need to be masked.
     * @param regex           The regular expression specifying the pattern to be replaced.
     * @param replacement     The replacement string for the matched pattern.
     * @param logMaskedValues Determines the Logging Level for the values Logged.
     * @param <T>             The type of the object.
     * @return The object with masked sensitive information.
     */
    public <T> T maskObjectValues(final T object, String regex, String replacement, boolean logMaskedValues) {
        int count = 0;
        if (Objects.isNull(object)) {
            return null;
        }
        setLogUnmaskedValues(logMaskedValues);
        // Log before masking
        logUnmaskedValues("Before Masking: " + object.toString());
        T maskedObject = maskObject(object, regex, replacement, count);
        // Log after masking
        logUnmaskedValues("After Masking: " + maskedObject.toString());
        return maskedObject;
    }

    /**
     * Masks the sensitive information in the fields of an object recursively.
     *
     * @param object      The object whose fields need to be masked.
     * @param regex       The regular expression specifying the pattern to be replaced.
     * @param replacement The replacement string for the matched pattern.
     * @param count       The count of recursive calls (used to determine if the object needs deep copying).
     * @param <T>         The type of the object.
     * @return The object with masked sensitive information.
     */
    private <T> T maskObject(final T object, String regex, String replacement, int count) {
        Object maskedObject;
        try {
            // If it's the first call, create a deep copy of the object to avoid modifying the original object
            if (count <= 0) {
                ObjectMapper objectMapper = new ObjectMapper();
                String objectJson = objectMapper.writeValueAsString(object);
                maskedObject = objectMapper.readValue(objectJson, object.getClass());
                count++;
            } else {
                // If it's a recursive call, use the original object
                maskedObject = object;
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage());
            return object;
        }

        // If regex is not provided, use the default regex
        regex = (regex != null && !regex.isEmpty()) ? regex : "\\w(?=\\w{2})";

        // If replacement is not provided, use the default replacement
        replacement = (replacement != null && !replacement.isEmpty()) ? replacement : "*";

        // Get the class of the object
        Class<?> clazz = maskedObject.getClass();

        // List of fields to skip during masking
        List<String> fieldsToSkip = Arrays.asList(
            "MIN_VALUE", "MAX_VALUE", "TYPE", "ANNOTATION", "ENUM", "SYNTHETIC",
            "cachedConstructor", "name", "module", "packageName", "componentType",
            "allPermDomain", "reflectionData", "classRedefinedCount", "genericInfo",
            "EMPTY_CLASS_ARRAY", "serialVersionUID", "serialPersistentFields",
            "reflectionFactory", "enumConstants", "enumConstantDirectory",
            "annotationData", "annotationType", "classValueMap", "digits", "DigitTens",
            "DigitOnes", "sizeTable", "value", "SIZE", "BYTES", "serialVersionUID"
        );

        // Iterate through fields and mask values based on regex and replacement
        for (Field field : clazz.getDeclaredFields()) {
            if (fieldsToSkip.stream().anyMatch(skipField -> field.getName().contains(skipField))) {
                continue;
            }
            try {
                field.setAccessible(true);
                Object value = field.get(maskedObject);

                if (value != null) {
                    if (value instanceof List) {
                        maskListValues((List<String>) value, regex, replacement, count, field.getName());
                    } else if (!field.getType().isPrimitive() && !field.getType().isAssignableFrom(String.class)) {
                        maskObject(value, regex, replacement, count);
                    } else if (field.getType().isAssignableFrom(String.class)) {
                        String maskedValue = mask(value, regex, replacement);
                        field.set(maskedObject, maskedValue);
                    }
                }
            } catch (IllegalAccessException e) {
                logger.error(e.getMessage());
            } finally {
                field.setAccessible(false);
            }
        }

        return (T) maskedObject;
    }

    /**
     * Masks the sensitive information in the elements of a List recursively.
     *
     * @param list        The List whose elements need to be masked.
     * @param regex       The regular expression specifying the pattern to be replaced.
     * @param replacement The replacement string for the matched pattern.
     * @param count       The count of recursive calls (used to determine if the object needs deep copying).
     * @param fieldName   The name of the field associated with the List.
     */
    private void maskListValues(List<String> list, String regex, String replacement, int count, String fieldName) {
        for (Object element : list) {
            if (element != null && !element.getClass().isPrimitive() && !element.getClass().isAssignableFrom(String.class)) {
                maskObject(element, regex, replacement, count);
            } else if (element instanceof String) {
                int index = list.indexOf(element);
                String maskedValue = mask((String) element, regex, replacement);
                list.set(index, maskedValue);
            }
        }
    }

}
