package com.bdo.evolution_native.demomodel.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * StatusType
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-16T03:45:59.282002926Z[GMT]")


public class StatusType   {
  @JsonProperty("StatusCode")
  private Integer statusCode = null;

  @JsonProperty("StatusDescription")
  private String statusDescription = null;

  @JsonProperty("SupportUID")
  private UUID supportUID = null;

  @JsonProperty("SupportDescription")
  private String supportDescription = null;

  @JsonProperty("ErrorCount")
  private Integer errorCount = null;

  @JsonProperty("WarningCount")
  private Integer warningCount = null;

  @JsonProperty("Errors")
  @Valid
  private List<ErrorType> errors = null;

  @JsonProperty("Warnings")
  @Valid
  private List<ErrorType> warnings = null;

  public StatusType statusCode(Integer statusCode) {
    this.statusCode = statusCode;
    return this;
  }

  /**
   * Status code
   * @return statusCode
   **/
  @Schema(description = "Status code")
  
    public Integer getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(Integer statusCode) {
    this.statusCode = statusCode;
  }

  public StatusType statusDescription(String statusDescription) {
    this.statusDescription = statusDescription;
    return this;
  }

  /**
   * Status description
   * @return statusDescription
   **/
  @Schema(description = "Status description")
  
  @Size(max=40)   public String getStatusDescription() {
    return statusDescription;
  }

  public void setStatusDescription(String statusDescription) {
    this.statusDescription = statusDescription;
  }

  public StatusType supportUID(UUID supportUID) {
    this.supportUID = supportUID;
    return this;
  }

  /**
   * Support id
   * @return supportUID
   **/
  @Schema(description = "Support id")
  
    @Valid
    public UUID getSupportUID() {
    return supportUID;
  }

  public void setSupportUID(UUID supportUID) {
    this.supportUID = supportUID;
  }

  public StatusType supportDescription(String supportDescription) {
    this.supportDescription = supportDescription;
    return this;
  }

  /**
   * Support description
   * @return supportDescription
   **/
  @Schema(description = "Support description")
  
  @Size(max=128)   public String getSupportDescription() {
    return supportDescription;
  }

  public void setSupportDescription(String supportDescription) {
    this.supportDescription = supportDescription;
  }

  public StatusType errorCount(Integer errorCount) {
    this.errorCount = errorCount;
    return this;
  }

  /**
   * Number of errors
   * @return errorCount
   **/
  @Schema(description = "Number of errors")
  
    public Integer getErrorCount() {
    return errorCount;
  }

  public void setErrorCount(Integer errorCount) {
    this.errorCount = errorCount;
  }

  public StatusType warningCount(Integer warningCount) {
    this.warningCount = warningCount;
    return this;
  }

  /**
   * Number of warnings
   * @return warningCount
   **/
  @Schema(description = "Number of warnings")
  
    public Integer getWarningCount() {
    return warningCount;
  }

  public void setWarningCount(Integer warningCount) {
    this.warningCount = warningCount;
  }

  public StatusType errors(List<ErrorType> errors) {
    this.errors = errors;
    return this;
  }

  public StatusType addErrorsItem(ErrorType errorsItem) {
    if (this.errors == null) {
      this.errors = new ArrayList<ErrorType>();
    }
    this.errors.add(errorsItem);
    return this;
  }

  /**
   * Get errors
   * @return errors
   **/
  @Schema(description = "")
      @Valid
    public List<ErrorType> getErrors() {
    return errors;
  }

  public void setErrors(List<ErrorType> errors) {
    this.errors = errors;
  }

  public StatusType warnings(List<ErrorType> warnings) {
    this.warnings = warnings;
    return this;
  }

  public StatusType addWarningsItem(ErrorType warningsItem) {
    if (this.warnings == null) {
      this.warnings = new ArrayList<ErrorType>();
    }
    this.warnings.add(warningsItem);
    return this;
  }

  /**
   * Get warnings
   * @return warnings
   **/
  @Schema(description = "")
      @Valid
    public List<ErrorType> getWarnings() {
    return warnings;
  }

  public void setWarnings(List<ErrorType> warnings) {
    this.warnings = warnings;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    StatusType statusType = (StatusType) o;
    return Objects.equals(this.statusCode, statusType.statusCode) &&
        Objects.equals(this.statusDescription, statusType.statusDescription) &&
        Objects.equals(this.supportUID, statusType.supportUID) &&
        Objects.equals(this.supportDescription, statusType.supportDescription) &&
        Objects.equals(this.errorCount, statusType.errorCount) &&
        Objects.equals(this.warningCount, statusType.warningCount) &&
        Objects.equals(this.errors, statusType.errors) &&
        Objects.equals(this.warnings, statusType.warnings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(statusCode, statusDescription, supportUID, supportDescription, errorCount, warningCount, errors, warnings);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class StatusType {\n");
    
    sb.append("    statusCode: ").append(toIndentedString(statusCode)).append("\n");
    sb.append("    statusDescription: ").append(toIndentedString(statusDescription)).append("\n");
    sb.append("    supportUID: ").append(toIndentedString(supportUID)).append("\n");
    sb.append("    supportDescription: ").append(toIndentedString(supportDescription)).append("\n");
    sb.append("    errorCount: ").append(toIndentedString(errorCount)).append("\n");
    sb.append("    warningCount: ").append(toIndentedString(warningCount)).append("\n");
    sb.append("    errors: ").append(toIndentedString(errors)).append("\n");
    sb.append("    warnings: ").append(toIndentedString(warnings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
