//package com.bdo.evolution_native.util;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.context.annotation.Scope;
//import org.springframework.stereotype.Component;
//
//import java.lang.reflect.Field;
//import java.util.Arrays;
//import java.util.List;
//
///**
// * Utility class for masking sensitive information.
// */
//
//@Component
//@Scope("prototype")
//public class MaskUtilDemo {
//
//    private int count = 0;
//
//    /**
//     * Masks the sensitive information in the given value with asterisks (*).
//     *
//     * <p>
//     * For example, if the input is "123456789", the output will be "*********".
//     * </p>
//     *
//     * @param value The sensitive information to be masked.
//     * @return The masked value.
//     */
//    public String mask(Object value) {
//        // Use a regex to replace each character with an asterisk, leaving the last four characters visible
//        String regex = "\\w(?=\\w{4})";
//        String replacement = "*";
//        return value.toString().replaceAll(regex, replacement);
//    }
//
//    /**
//     * Masks the sensitive information in the given value based on custom regex and replacement.
//     *
//     * @param value       The sensitive information to be masked.
//     * @param regex       The regular expression specifying the pattern to be replaced.
//     * @param replacement The replacement string for the matched pattern.
//     * @return The masked value.
//     */
//    public String mask(Object value, String regex, String replacement) {
//        // Use a custom regex and replacement to mask sensitive information
//        return value.toString().replaceAll(regex, replacement);
//    }
//
//    public <T> T maskObjectValues(final T object1, String regex, String replacement) throws JsonProcessingException {
//        Object object;
//        if(count <= 0) {
//            ObjectMapper objectMapper = new ObjectMapper();
//            String custListInqRsJson = objectMapper.writeValueAsString(object1);
//            object = objectMapper.readValue(custListInqRsJson, object1.getClass());
//            count++;
//        }
//        else {
//            object = object1;
//        }
//    }
//    /**
//     * Masks the sensitive information in the fields of an object recursively.
//     *
//     * @param object      The object whose fields need to be masked.
//     * @param regex       The regular expression specifying the pattern to be replaced.
//     * @param replacement The replacement string for the matched pattern.
//     * @param <T>         The type of the object.
//     * @return The object with masked sensitive information.
//     */
//    public <T> T maskObjectValues2(final T object, String regex, String replacement) throws JsonProcessingException {
//
//        // If regex is not provided, use the default regex
//        regex = (regex != null && !regex.isEmpty()) ? regex : "\\w(?=\\w{4})";
//
//        // If replacement is not provided, use the default replacement
//        replacement = (replacement != null && !replacement.isEmpty()) ? replacement : "*";
//
//        // Get the class of the object
//        Class<?> clazz = object.getClass();
//        List<String> fieldsToSkip = Arrays.asList(
//            "MIN_VALUE", "MAX_VALUE", "TYPE", "ANNOTATION", "ENUM", "SYNTHETIC",
//            "cachedConstructor", "name", "module", "packageName", "componentType",
//            "allPermDomain", "reflectionData", "classRedefinedCount", "genericInfo",
//            "EMPTY_CLASS_ARRAY", "serialVersionUID", "serialPersistentFields",
//            "reflectionFactory", "enumConstants", "enumConstantDirectory",
//            "annotationData", "annotationType", "classValueMap", "digits", "DigitTens",
//            "DigitOnes", "sizeTable", "value", "SIZE", "BYTES", "serialVersionUID"
//        );
//
//
//
//        // Iterate through fields and mask values based on regex and replacement
//        for (Field field : clazz.getDeclaredFields()) {
//            if (fieldsToSkip.stream().anyMatch(skipField -> field.getName().contains(skipField))) {
////                System.out.println("Skipping field: " + field.getName());
//                continue;
//            }
////            if(count < 6){
////                count++;
////            }
////            else {
////                break;
////            }
//            try {
//                // Ensure field is accessible
////                System.out.println(field.getName());
////                if(field.getName().equals("rqUID") || field.getName().equals("requestUid") || field.getName().equals("status") || field.getName().equals("statusCode")) {
////                    field.setAccessible(true);
////                }
//                field.setAccessible(true);
//                Object value = "";
//                if (field.get(object) != null) {
//                    // Get the current value of the field
//                    value = field.get(object);
//                } else {
//                    continue;
//                }
//
//                // If the value is a List, mask its values
//                if (value instanceof List) {
//                    maskListValues((List<String>) value, regex, replacement);
//                } else if (value != null && !field.getType().isPrimitive() && !field.getType().isAssignableFrom(String.class)) {
//                    // If the value is an object, recursively mask its values
//                    maskObjectValues(value, regex, replacement);
//                } else if (field.getType().isAssignableFrom(String.class)) {
//                    // Apply masking to String fields
//                    String maskedValue = mask(value, regex, replacement);
//                    field.set(object, maskedValue);
//                }
//            } catch (IllegalAccessException e) {
//                System.out.println(e.getMessage());
//            }
//            finally {
//                // It's good practice to reset accessibility to its original state in a finally block
//                field.setAccessible(false);
//            }
//        }
//
//        return (T) object;
//    }
//
//    /**
//     * Masks the sensitive information in the elements of a List recursively.
//     *
//     * @param list        The List whose elements need to be masked.
//     * @param regex       The regular expression specifying the pattern to be replaced.
//     * @param replacement The replacement string for the matched pattern.
//     */
//    private void maskListValues(List<String> list, String regex, String replacement) throws JsonProcessingException {
//        for (Object element : list) {
//            if (element != null && !element.getClass().isPrimitive() && !element.getClass().isAssignableFrom(String.class)) {
//                // If the element is an object, recursively mask its values
//                maskObjectValues(element, regex, replacement);
//            } else if (element instanceof String) {
//                // If the element is a String, mask its value
//                int index = list.indexOf(element);
//                String maskedValue = mask((String) element, regex, replacement);
//                list.set(index, maskedValue);
//            }
//        }
//    }
//}