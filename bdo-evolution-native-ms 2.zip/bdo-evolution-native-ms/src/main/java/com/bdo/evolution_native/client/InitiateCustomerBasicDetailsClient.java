package com.bdo.evolution_native.client;

import com.bdo.evolution_native.client.model.addcard.CardAcctAddRs;
import com.bdo.evolution_native.client.model.initiatemodel.CustProfBasicAddRq;
import com.bdo.evolution_native.client.model.initiatemodel.CustProfBasicAddRs;
import com.bdo.evolution_native.config.WebClientConfig;
import com.bdo.evolution_native.constants.EvolutionConstantUtils;
import com.bdo.evolution_native.exception.EvolutionException;
import com.bdo.evolution_native.exception.SystemApiError;
import com.bdo.evolution_native.util.MaskUtil;
import com.bdo.evolution_native.util.MethodLogger;
import com.bdo.evolution_native.util.ObjectMapperUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * The type Collateral client.
 */
@Component
@NoArgsConstructor
public class InitiateCustomerBasicDetailsClient {
    private final Logger logger = LoggerFactory.getLogger(InitiateCustomerBasicDetailsClient.class);
    @Autowired
    private MaskUtil maskUtil;

    @Autowired
    private WebClientConfig webClientConfig;
    @Autowired
    private TokenManagerClient tokenManagerClient;

    @Value("${EVOLUTION.CUSTOMER.INITIATE.PATH}")
    private String path;
    @Value("${EVOLUTION.BASE_URL}")
    private String baseUrl;
    @Value("${EVOLUTION.TOKEN.PATH}")
    private String tokenPath;
    @Value("${EVOLUTION.TOKEN.CHANNEL_ID_HEADER}")
    private String channelIdHeader;
    @Value("${EVOLUTION.TOKEN.SOURCE_HEADER}")
    private String sourceHeader;

    /**
     * Instantiates a new Collateral client.
     *
     * @param webClientConfig The web client config
     */
    public InitiateCustomerBasicDetailsClient(final String baseUrl,
                                              final String path,
                                              final String tokenPath,
                                              final String channelIdHeader,
                                              final String sourceHeader,
                                              final WebClientConfig webClientConfig,
                                              final TokenManagerClient tokenManagerClient) {
        this.baseUrl = baseUrl;
        this.path = path;
        this.tokenPath = tokenPath;
        this.channelIdHeader = channelIdHeader;
        this.sourceHeader = sourceHeader;
        this.webClientConfig = webClientConfig;
        this.tokenManagerClient = tokenManagerClient;
    }

    /**
     * This method calling SOR using WebClient.
     *
     * @return InitiateCustomerBasicDetailsClient mono
     */
    @MethodLogger
    public Mono<CustProfBasicAddRs> initiateCustomerClient(final CustProfBasicAddRq request) {
        return tokenManagerClient.getAccessToken(tokenPath, channelIdHeader, sourceHeader)
            .flatMap(token -> {
                final String requestObject;
                try {
                    requestObject = ObjectMapperUtil.createObjectMapper(request);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }

                logger.info("SOR: {} {} {} {} {} {}",
                    baseUrl, path,
                    EvolutionConstantUtils.AUTHORIZATION_HEADER,
                    EvolutionConstantUtils.BEARER,
                    token, requestObject);
                return webClientConfig.getWebClient().post()
                    .uri(baseUrl + path)
                    .accept(MediaType.APPLICATION_JSON)
                    .header(EvolutionConstantUtils.AUTHORIZATION_HEADER, EvolutionConstantUtils.BEARER
                        + token)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(CustProfBasicAddRs.class)
                    .retryWhen(webClientConfig.retryForServerError())
                    .retryWhen(webClientConfig.retryForConnectionError())
                    .onErrorMap(webClientConfig::handleErrors)
                    .switchIfEmpty(Mono.error(new SystemApiError(EvolutionConstantUtils.EMPTY_SOR_RESPONSE)))
                    .map(this::handleCustProfBasicAddRs);
            });
    }

    private CustProfBasicAddRs handleCustProfBasicAddRs(final CustProfBasicAddRs custProfBasicAddRs) {
        try {
            final String custProfBasicAddRsObject = ObjectMapperUtil.createObjectMapper(custProfBasicAddRs);
            logger.info(custProfBasicAddRsObject);
        } catch (final JsonProcessingException exception) {
            throw new RuntimeException(exception);
        }

        if (!custProfBasicAddRs.getStatus()
            .getStatusCode().equals(EvolutionConstantUtils.ZERO)) {
            throw new EvolutionException(custProfBasicAddRs.getStatus());
        }
        return custProfBasicAddRs;
    }
}
