package com.bdo.evolution_native.demomodel.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Size;
import java.util.Objects;

/**
 * PhoneNumber
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-16T03:45:59.282002926Z[GMT]")


public class PhoneNumber   {
  @JsonProperty("PhoneType")
  private String phoneType = null;

  @JsonProperty("Phone")
  private String phone = null;

  @JsonProperty("IntlDialCode")
  private String intlDialCode = null;

  @JsonProperty("PhoneExtension")
  private String phoneExtension = null;

  public PhoneNumber phoneType(String phoneType) {
    this.phoneType = phoneType;
    return this;
  }

  /**
   * Get phoneType
   * @return phoneType
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPhoneType() {
    return phoneType;
  }

  public void setPhoneType(String phoneType) {
    this.phoneType = phoneType;
  }

  public PhoneNumber phone(String phone) {
    this.phone = phone;
    return this;
  }

  /**
   * Get phone
   * @return phone
   **/
  @Schema(description = "")
  
  @Size(max=7)   public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public PhoneNumber intlDialCode(String intlDialCode) {
    this.intlDialCode = intlDialCode;
    return this;
  }

  /**
   * Postal code string
   * @return intlDialCode
   **/
  @Schema(description = "Postal code string")
  
  @Size(max=5)   public String getIntlDialCode() {
    return intlDialCode;
  }

  public void setIntlDialCode(String intlDialCode) {
    this.intlDialCode = intlDialCode;
  }

  public PhoneNumber phoneExtension(String phoneExtension) {
    this.phoneExtension = phoneExtension;
    return this;
  }

  /**
   * Address code
   * @return phoneExtension
   **/
  @Schema(description = "Address code")
  
  @Size(max=5)   public String getPhoneExtension() {
    return phoneExtension;
  }

  public void setPhoneExtension(String phoneExtension) {
    this.phoneExtension = phoneExtension;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PhoneNumber phoneNumber = (PhoneNumber) o;
    return Objects.equals(this.phoneType, phoneNumber.phoneType) &&
        Objects.equals(this.phone, phoneNumber.phone) &&
        Objects.equals(this.intlDialCode, phoneNumber.intlDialCode) &&
        Objects.equals(this.phoneExtension, phoneNumber.phoneExtension);
  }

  @Override
  public int hashCode() {
    return Objects.hash(phoneType, phone, intlDialCode, phoneExtension);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PhoneNumber {\n");
    
    sb.append("    phoneType: ").append(toIndentedString(phoneType)).append("\n");
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("    intlDialCode: ").append(toIndentedString(intlDialCode)).append("\n");
    sb.append("    phoneExtension: ").append(toIndentedString(phoneExtension)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
