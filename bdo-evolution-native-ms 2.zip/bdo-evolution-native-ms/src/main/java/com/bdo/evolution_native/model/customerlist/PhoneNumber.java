package com.bdo.evolution_native.model.customerlist;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * PhoneNumber
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class PhoneNumber {
    @JsonProperty("PhoneType")
    private String phoneType;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("IntlDialCode")
    private String intlDialCode;
    @JsonProperty("PhoneExtension")
    private String phoneExtension;
}