package com.bdo.evolution_native.config;

import com.bdo.common.swagger.SwaggerConfig;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DemoSwagger extends SwaggerConfig {

}
