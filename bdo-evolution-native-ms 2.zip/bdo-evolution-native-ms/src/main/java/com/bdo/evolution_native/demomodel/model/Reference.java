package com.bdo.evolution_native.demomodel.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.threeten.bp.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Reference
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-16T03:45:59.282002926Z[GMT]")


public class Reference   {
  @JsonProperty("CustomerPermanentId")
  private String customerPermanentId = null;

  @JsonProperty("CustomerType")
  private String customerType = null;

  @JsonProperty("CustomerMailCustomerCode")
  private String customerMailCustomerCode = null;

  @JsonProperty("CustomerStatusCode")
  private String customerStatusCode = null;

  @JsonProperty("CustAccountRelationshipType")
  private String custAccountRelationshipType = null;

  @JsonProperty("CustomerName")
  private String customerName = null;

  @JsonProperty("DateOfBirth")
  private LocalDate dateOfBirth = null;

  @JsonProperty("CitizenCode")
  private String citizenCode = null;

  @JsonProperty("ResidenceCode")
  private String residenceCode = null;

  @JsonProperty("RiskCode")
  private String riskCode = null;

  @JsonProperty("CustomerAddress")
  private CustomerAddress customerAddress = null;

  @JsonProperty("PhoneNumber")
  private PhoneNumber phoneNumber = null;

  @JsonProperty("EmailAddress")
  private String emailAddress = null;

  @JsonProperty("MobileNumber")
  private BigDecimal mobileNumber = null;

  @JsonProperty("NationalId")
  private String nationalId = null;

  @JsonProperty("TaxInformationCode")
  private String taxInformationCode = null;

  @JsonProperty("TaxId")
  private String taxId = null;

  @JsonProperty("BranchId")
  private String branchId = null;

  public Reference customerPermanentId(String customerPermanentId) {
    this.customerPermanentId = customerPermanentId;
    return this;
  }

  /**
   * Customer number
   * @return customerPermanentId
   **/
  @Schema(description = "Customer number")
  
  @Size(max=10)   public String getCustomerPermanentId() {
    return customerPermanentId;
  }

  public void setCustomerPermanentId(String customerPermanentId) {
    this.customerPermanentId = customerPermanentId;
  }

  public Reference customerType(String customerType) {
    this.customerType = customerType;
    return this;
  }

  /**
   * Customer type
   * @return customerType
   **/
  @Schema(example = "Personal/Business", description = "Customer type")
  
    public String getCustomerType() {
    return customerType;
  }

  public void setCustomerType(String customerType) {
    this.customerType = customerType;
  }

  public Reference customerMailCustomerCode(String customerMailCustomerCode) {
    this.customerMailCustomerCode = customerMailCustomerCode;
    return this;
  }

  /**
   * Customer mail customer code
   * @return customerMailCustomerCode
   **/
  @Schema(description = "Customer mail customer code")
  
    public String getCustomerMailCustomerCode() {
    return customerMailCustomerCode;
  }

  public void setCustomerMailCustomerCode(String customerMailCustomerCode) {
    this.customerMailCustomerCode = customerMailCustomerCode;
  }

  public Reference customerStatusCode(String customerStatusCode) {
    this.customerStatusCode = customerStatusCode;
    return this;
  }

  /**
   * Customer number
   * @return customerStatusCode
   **/
  @Schema(example = "Blank/F/I/U", description = "Customer number")
  
    public String getCustomerStatusCode() {
    return customerStatusCode;
  }

  public void setCustomerStatusCode(String customerStatusCode) {
    this.customerStatusCode = customerStatusCode;
  }

  public Reference custAccountRelationshipType(String custAccountRelationshipType) {
    this.custAccountRelationshipType = custAccountRelationshipType;
    return this;
  }

  /**
   * CustAcctRelType
   * @return custAccountRelationshipType
   **/
  @Schema(description = "CustAcctRelType")
  
    public String getCustAccountRelationshipType() {
    return custAccountRelationshipType;
  }

  public void setCustAccountRelationshipType(String custAccountRelationshipType) {
    this.custAccountRelationshipType = custAccountRelationshipType;
  }

  public Reference customerName(String customerName) {
    this.customerName = customerName;
    return this;
  }

  /**
   * Full Name
   * @return customerName
   **/
  @Schema(description = "Full Name")
  
    public String getCustomerName() {
    return customerName;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public Reference dateOfBirth(LocalDate dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
    return this;
  }

  /**
   * Get dateOfBirth
   * @return dateOfBirth
   **/
  @Schema(description = "")
  
    @Valid
    public LocalDate getDateOfBirth() {
    return dateOfBirth;
  }

  public void setDateOfBirth(LocalDate dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public Reference citizenCode(String citizenCode) {
    this.citizenCode = citizenCode;
    return this;
  }

  /**
   * CitizenCode
   * @return citizenCode
   **/
  @Schema(description = "CitizenCode")
  
    public String getCitizenCode() {
    return citizenCode;
  }

  public void setCitizenCode(String citizenCode) {
    this.citizenCode = citizenCode;
  }

  public Reference residenceCode(String residenceCode) {
    this.residenceCode = residenceCode;
    return this;
  }

  /**
   * ResidenceCode
   * @return residenceCode
   **/
  @Schema(description = "ResidenceCode")
  
    public String getResidenceCode() {
    return residenceCode;
  }

  public void setResidenceCode(String residenceCode) {
    this.residenceCode = residenceCode;
  }

  public Reference riskCode(String riskCode) {
    this.riskCode = riskCode;
    return this;
  }

  /**
   * RiskCode
   * @return riskCode
   **/
  @Schema(description = "RiskCode")
  
    public String getRiskCode() {
    return riskCode;
  }

  public void setRiskCode(String riskCode) {
    this.riskCode = riskCode;
  }

  public Reference customerAddress(CustomerAddress customerAddress) {
    this.customerAddress = customerAddress;
    return this;
  }

  /**
   * Get customerAddress
   * @return customerAddress
   **/
  @Schema(description = "")
  
    @Valid
    public CustomerAddress getCustomerAddress() {
    return customerAddress;
  }

  public void setCustomerAddress(CustomerAddress customerAddress) {
    this.customerAddress = customerAddress;
  }

  public Reference phoneNumber(PhoneNumber phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

  /**
   * Get phoneNumber
   * @return phoneNumber
   **/
  @Schema(description = "")
  
    @Valid
    public PhoneNumber getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(PhoneNumber phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public Reference emailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  /**
   * EmailAddress
   * @return emailAddress
   **/
  @Schema(description = "EmailAddress")
  
    public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public Reference mobileNumber(BigDecimal mobileNumber) {
    this.mobileNumber = mobileNumber;
    return this;
  }

  /**
   * Mobile number of the customer
   * @return mobileNumber
   **/
  @Schema(description = "Mobile number of the customer")
  
    @Valid
    public BigDecimal getMobileNumber() {
    return mobileNumber;
  }

  public void setMobileNumber(BigDecimal mobileNumber) {
    this.mobileNumber = mobileNumber;
  }

  public Reference nationalId(String nationalId) {
    this.nationalId = nationalId;
    return this;
  }

  /**
   * National Id
   * @return nationalId
   **/
  @Schema(description = "National Id")
  
    public String getNationalId() {
    return nationalId;
  }

  public void setNationalId(String nationalId) {
    this.nationalId = nationalId;
  }

  public Reference taxInformationCode(String taxInformationCode) {
    this.taxInformationCode = taxInformationCode;
    return this;
  }

  /**
   * Tax Information Code
   * @return taxInformationCode
   **/
  @Schema(description = "Tax Information Code")
  
    public String getTaxInformationCode() {
    return taxInformationCode;
  }

  public void setTaxInformationCode(String taxInformationCode) {
    this.taxInformationCode = taxInformationCode;
  }

  public Reference taxId(String taxId) {
    this.taxId = taxId;
    return this;
  }

  /**
   * Tax Id
   * @return taxId
   **/
  @Schema(description = "Tax Id")
  
    public String getTaxId() {
    return taxId;
  }

  public void setTaxId(String taxId) {
    this.taxId = taxId;
  }

  public Reference branchId(String branchId) {
    this.branchId = branchId;
    return this;
  }

  /**
   * Branch Id
   * @return branchId
   **/
  @Schema(description = "Branch Id")
  
    public String getBranchId() {
    return branchId;
  }

  public void setBranchId(String branchId) {
    this.branchId = branchId;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Reference reference = (Reference) o;
    return Objects.equals(this.customerPermanentId, reference.customerPermanentId) &&
        Objects.equals(this.customerType, reference.customerType) &&
        Objects.equals(this.customerMailCustomerCode, reference.customerMailCustomerCode) &&
        Objects.equals(this.customerStatusCode, reference.customerStatusCode) &&
        Objects.equals(this.custAccountRelationshipType, reference.custAccountRelationshipType) &&
        Objects.equals(this.customerName, reference.customerName) &&
        Objects.equals(this.dateOfBirth, reference.dateOfBirth) &&
        Objects.equals(this.citizenCode, reference.citizenCode) &&
        Objects.equals(this.residenceCode, reference.residenceCode) &&
        Objects.equals(this.riskCode, reference.riskCode) &&
        Objects.equals(this.customerAddress, reference.customerAddress) &&
        Objects.equals(this.phoneNumber, reference.phoneNumber) &&
        Objects.equals(this.emailAddress, reference.emailAddress) &&
        Objects.equals(this.mobileNumber, reference.mobileNumber) &&
        Objects.equals(this.nationalId, reference.nationalId) &&
        Objects.equals(this.taxInformationCode, reference.taxInformationCode) &&
        Objects.equals(this.taxId, reference.taxId) &&
        Objects.equals(this.branchId, reference.branchId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(customerPermanentId, customerType, customerMailCustomerCode, customerStatusCode, custAccountRelationshipType, customerName, dateOfBirth, citizenCode, residenceCode, riskCode, customerAddress, phoneNumber, emailAddress, mobileNumber, nationalId, taxInformationCode, taxId, branchId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Reference {\n");
    
    sb.append("    customerPermanentId: ").append(toIndentedString(customerPermanentId)).append("\n");
    sb.append("    customerType: ").append(toIndentedString(customerType)).append("\n");
    sb.append("    customerMailCustomerCode: ").append(toIndentedString(customerMailCustomerCode)).append("\n");
    sb.append("    customerStatusCode: ").append(toIndentedString(customerStatusCode)).append("\n");
    sb.append("    custAccountRelationshipType: ").append(toIndentedString(custAccountRelationshipType)).append("\n");
    sb.append("    customerName: ").append(toIndentedString(customerName)).append("\n");
    sb.append("    dateOfBirth: ").append(toIndentedString(dateOfBirth)).append("\n");
    sb.append("    citizenCode: ").append(toIndentedString(citizenCode)).append("\n");
    sb.append("    residenceCode: ").append(toIndentedString(residenceCode)).append("\n");
    sb.append("    riskCode: ").append(toIndentedString(riskCode)).append("\n");
    sb.append("    customerAddress: ").append(toIndentedString(customerAddress)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    mobileNumber: ").append(toIndentedString(mobileNumber)).append("\n");
    sb.append("    nationalId: ").append(toIndentedString(nationalId)).append("\n");
    sb.append("    taxInformationCode: ").append(toIndentedString(taxInformationCode)).append("\n");
    sb.append("    taxId: ").append(toIndentedString(taxId)).append("\n");
    sb.append("    branchId: ").append(toIndentedString(branchId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
