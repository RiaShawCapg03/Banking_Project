//package com.bdo.evolution_native.util;
//
//import ch.qos.logback.classic.Level;
//import ch.qos.logback.classic.Logger;
//import org.slf4j.Marker;
//import org.slf4j.MarkerFactory;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Component;
//
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import java.io.IOException;
//
//@Component
//public class LoggingFilter implements Filter {
//
//    private static final Marker MASK_MARKER = MarkerFactory.getMarker("MASK");
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException { }
//
//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//        throws IOException, ServletException {
//        try {
//            // Your masking logic here before logging
//            Logger logger = (Logger) LoggerFactory.getLogger("com.bdo.evolution_native");
//            logger.log(MASK_MARKER, this.getClass().getName(), Level.INFO.levelInt, "Masking sensitive information", null, null);
//            chain.doFilter(request, response);
//        } finally {
//            // Clean up if needed
//        }
//    }
//
//    @Override
//    public void destroy() { }
//}
