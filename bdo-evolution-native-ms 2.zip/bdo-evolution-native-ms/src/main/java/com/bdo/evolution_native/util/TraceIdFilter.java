package com.bdo.evolution_native.util;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.bdo.evolution_native.constants.EvolutionConstantUtils;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import static com.bdo.evolution_native.constants.EvolutionConstantUtils.*;

public class TraceIdFilter implements Filter {
    private static final Marker MASK_MARKER = MarkerFactory.getMarker("MASK");
    @Override
    public void init(final FilterConfig filterConfig) throws ServletException {
        // Initialization code if needed
    }

    @Override
    public void doFilter(final ServletRequest servletRequest, final ServletResponse servletResponse,
                         final FilterChain chain)
            throws IOException, ServletException {
        if (servletRequest instanceof HttpServletRequest && servletResponse instanceof HttpServletResponse) {
            final HttpServletRequest request = (HttpServletRequest) servletRequest;
            final HttpServletResponse response = (HttpServletResponse) servletResponse;
            final Map<String, String> headerMap = new ConcurrentHashMap<>();
            final Enumeration<String> headerNames = request.getHeaderNames();
            while (Objects.nonNull(headerNames) && headerNames.hasMoreElements()) {
                final String headerName = headerNames.nextElement();
                final String headerValue = request.getHeader(headerName);
                switch (headerName) {
                    case AUTH_DATE_CONST:
                    case CUST_ADDRESS_CONST:
                    case INTERACTION_ID_CONST:
                    case CUST_USER_AGENT_CONST:
                    case GENERATED_ID_CONST:
                    case REQUEST_ID_CONST:
                        headerMap.put(headerName, headerValue);
                        break;
                    default:
                        break;
                }
            }
            MDC.put(EvolutionConstantUtils.HEADER_MAP, headerMap.toString());

            chain.doFilter(request, response);
        } else {
            throw new ServletException(EvolutionConstantUtils.HTTP_SUPPORT_ONLY_EXCEPTION);
        }
        Logger logger = (Logger) LoggerFactory.getLogger("com.bdo.evolution_native");
        logger.log(MASK_MARKER, this.getClass().getName(), Level.INFO, "Masking sensitive information", null, null);
        chain.doFilter(servletRequest, servletResponse);

    }

    @Override
    public void destroy() {
        // Cleanup code if needed
    }
}
