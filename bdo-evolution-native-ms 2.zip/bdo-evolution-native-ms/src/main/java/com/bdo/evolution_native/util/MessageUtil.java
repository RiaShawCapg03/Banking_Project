//package com.bdo.evolution_native.util;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Component;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.Properties;
//
///**
// * Utility class for retrieving messages from a properties file.
// */
//@Component
//public class MessageUtil {
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(MessageUtil.class);
//
//    private Properties msgProperties;
//
//    /**
//     * Constructs a new MessageUtil and loads the message.properties file.
//     */
//    public MessageUtil() {
//        try (InputStream inStream = getClass().getClassLoader().getResourceAsStream("message.properties")) {
//            msgProperties = new Properties();
//            msgProperties.load(inStream);
//        } catch (final IOException exception) {
//            LOGGER.error("Exception in MessageUtil Catch: {} ", exception.getMessage());
//        }
//    }
//
//    /**
//     * Retrieves the value associated with the given key from the message.properties file.
//     *
//     * @param key The key for which to retrieve the value.
//     * @return The value associated with the key, or null if the key is not found.
//     */
//    public String getBundle(final String key) {
//        return msgProperties.getProperty(key);
//    }
//}
