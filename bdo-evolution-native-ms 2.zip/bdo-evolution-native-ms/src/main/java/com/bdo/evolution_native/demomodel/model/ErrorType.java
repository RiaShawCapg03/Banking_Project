package com.bdo.evolution_native.demomodel.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * ErrorType
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2024-01-16T03:45:59.282002926Z[GMT]")


public class ErrorType   {
  @JsonProperty("Source")
  private String source = null;

  @JsonProperty("ErrorNumber")
  private String errorNumber = null;

  @JsonProperty("ErrorDescription")
  private String errorDescription = null;

  @JsonProperty("ErrorDetails")
  private String errorDetails = null;

  @JsonProperty("errField")
  private String errField = null;

  @JsonProperty("ErrorType")
  private String errorType = null;

  @JsonProperty("ErrorTagName")
  private String errorTagName = null;

  @JsonProperty("HostErrorCode")
  private String hostErrorCode = null;

  @JsonProperty("UseCode")
  private String useCode = null;

  @JsonProperty("SupportUID")
  private String supportUID = null;

  @JsonProperty("Rows")
  @Valid
  private List<Integer> rows = null;

  public ErrorType source(String source) {
    this.source = source;
    return this;
  }

  /**
   * Source(reserved)
   * @return source
   **/
  @Schema(description = "Source(reserved)")
  
  @Size(max=64)   public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public ErrorType errorNumber(String errorNumber) {
    this.errorNumber = errorNumber;
    return this;
  }

  /**
   * Total number of errors
   * @return errorNumber
   **/
  @Schema(description = "Total number of errors")
  
    public String getErrorNumber() {
    return errorNumber;
  }

  public void setErrorNumber(String errorNumber) {
    this.errorNumber = errorNumber;
  }

  public ErrorType errorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
    return this;
  }

  /**
   * Error description
   * @return errorDescription
   **/
  @Schema(description = "Error description")
  
  @Size(max=50)   public String getErrorDescription() {
    return errorDescription;
  }

  public void setErrorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
  }

  public ErrorType errorDetails(String errorDetails) {
    this.errorDetails = errorDetails;
    return this;
  }

  /**
   * Error detail
   * @return errorDetails
   **/
  @Schema(description = "Error detail")
  
  @Size(max=128)   public String getErrorDetails() {
    return errorDetails;
  }

  public void setErrorDetails(String errorDetails) {
    this.errorDetails = errorDetails;
  }

  public ErrorType errField(String errField) {
    this.errField = errField;
    return this;
  }

  /**
   * Field in error
   * @return errField
   **/
  @Schema(description = "Field in error")
  
  @Size(max=32)   public String getErrField() {
    return errField;
  }

  public void setErrField(String errField) {
    this.errField = errField;
  }

  public ErrorType errorType(String errorType) {
    this.errorType = errorType;
    return this;
  }

  /**
   * Error type
   * @return errorType
   **/
  @Schema(description = "Error type")
  
  @Size(min=1,max=1)   public String getErrorType() {
    return errorType;
  }

  public void setErrorType(String errorType) {
    this.errorType = errorType;
  }

  public ErrorType errorTagName(String errorTagName) {
    this.errorTagName = errorTagName;
    return this;
  }

  /**
   * Reserved
   * @return errorTagName
   **/
  @Schema(description = "Reserved")
  
  @Size(max=32)   public String getErrorTagName() {
    return errorTagName;
  }

  public void setErrorTagName(String errorTagName) {
    this.errorTagName = errorTagName;
  }

  public ErrorType hostErrorCode(String hostErrorCode) {
    this.hostErrorCode = hostErrorCode;
    return this;
  }

  /**
   * Host error message id
   * @return hostErrorCode
   **/
  @Schema(description = "Host error message id")
  
  @Size(max=7)   public String getHostErrorCode() {
    return hostErrorCode;
  }

  public void setHostErrorCode(String hostErrorCode) {
    this.hostErrorCode = hostErrorCode;
  }

  public ErrorType useCode(String useCode) {
    this.useCode = useCode;
    return this;
  }

  /**
   * Reserved
   * @return useCode
   **/
  @Schema(description = "Reserved")
  
  @Size(max=2)   public String getUseCode() {
    return useCode;
  }

  public void setUseCode(String useCode) {
    this.useCode = useCode;
  }

  public ErrorType supportUID(String supportUID) {
    this.supportUID = supportUID;
    return this;
  }

  /**
   * Support id
   * @return supportUID
   **/
  @Schema(description = "Support id")
  
    public String getSupportUID() {
    return supportUID;
  }

  public void setSupportUID(String supportUID) {
    this.supportUID = supportUID;
  }

  public ErrorType rows(List<Integer> rows) {
    this.rows = rows;
    return this;
  }

  public ErrorType addRowsItem(Integer rowsItem) {
    if (this.rows == null) {
      this.rows = new ArrayList<Integer>();
    }
    this.rows.add(rowsItem);
    return this;
  }

  /**
   * Get rows
   * @return rows
   **/
  @Schema(description = "")
  
    public List<Integer> getRows() {
    return rows;
  }

  public void setRows(List<Integer> rows) {
    this.rows = rows;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorType errorType = (ErrorType) o;
    return Objects.equals(this.source, errorType.source) &&
        Objects.equals(this.errorNumber, errorType.errorNumber) &&
        Objects.equals(this.errorDescription, errorType.errorDescription) &&
        Objects.equals(this.errorDetails, errorType.errorDetails) &&
        Objects.equals(this.errField, errorType.errField) &&
        Objects.equals(this.errorType, errorType.errorType) &&
        Objects.equals(this.errorTagName, errorType.errorTagName) &&
        Objects.equals(this.hostErrorCode, errorType.hostErrorCode) &&
        Objects.equals(this.useCode, errorType.useCode) &&
        Objects.equals(this.supportUID, errorType.supportUID) &&
        Objects.equals(this.rows, errorType.rows);
  }

  @Override
  public int hashCode() {
    return Objects.hash(source, errorNumber, errorDescription, errorDetails, errField, errorType, errorTagName, hostErrorCode, useCode, supportUID, rows);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorType {\n");
    
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    errorNumber: ").append(toIndentedString(errorNumber)).append("\n");
    sb.append("    errorDescription: ").append(toIndentedString(errorDescription)).append("\n");
    sb.append("    errorDetails: ").append(toIndentedString(errorDetails)).append("\n");
    sb.append("    errField: ").append(toIndentedString(errField)).append("\n");
    sb.append("    errorType: ").append(toIndentedString(errorType)).append("\n");
    sb.append("    errorTagName: ").append(toIndentedString(errorTagName)).append("\n");
    sb.append("    hostErrorCode: ").append(toIndentedString(hostErrorCode)).append("\n");
    sb.append("    useCode: ").append(toIndentedString(useCode)).append("\n");
    sb.append("    supportUID: ").append(toIndentedString(supportUID)).append("\n");
    sb.append("    rows: ").append(toIndentedString(rows)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
