package com.bdo.evolution_native.client;

import com.bdo.evolution_native.client.model.AccessTokenResponse;
import com.bdo.evolution_native.config.TokenClientConfig;
import com.bdo.evolution_native.exception.SystemApiError;
import com.bdo.evolution_native.util.MaskUtil;
import com.bdo.evolution_native.util.MethodLogger;
import com.bdo.evolution_native.util.ObjectMapperUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Optional;

import static com.bdo.evolution_native.constants.EvolutionConstantUtils.*;

@Component
public class TokenManagerClient {
    private final Logger logger = LoggerFactory.getLogger(TokenManagerClient.class);
    @Autowired
    private MaskUtil maskUtil;
    @Autowired
    private TokenClientConfig tokenClientConfig;

    /**
     * This method is used to Check the Access Token
     *
     * @return String
     */

    @MethodLogger
    public Mono<String> getAccessToken(final String tokenPath, final String channelIdHeader,
                                       final String sourceHeader) {
        logger.info("Token Call :: " + "TokenUrl: " + tokenPath + ", Headers: " +  CHANNEL_ID_HEADER + ": "
                + channelIdHeader + ", " + SOURCE_HEADER + ": " + sourceHeader);
        return tokenClientConfig.getOauthWebClient().get()
                .uri(tokenPath)
                .accept(MediaType.APPLICATION_JSON)
                .header(CHANNEL_ID_HEADER, channelIdHeader)
                .header(SOURCE_HEADER, sourceHeader)
                .retrieve()
                .bodyToMono(AccessTokenResponse.class)
                .retryWhen(tokenClientConfig.retryForOauthServerError())
                .retryWhen(tokenClientConfig.retryForOauthConnectionError())
                .onErrorMap(tokenClientConfig::oAuthHandleErrors)
                .switchIfEmpty(Mono.error(new SystemApiError(EMPTY_OAUTH_RESPONSE)))
                .map(accessTokenResponse -> {
                    final String accessTokenResponseObject;
                    try {
                        accessTokenResponseObject = ObjectMapperUtil.createObjectMapper(accessTokenResponse);
                    } catch (final JsonProcessingException exception) {
                        throw new RuntimeException(exception);
                    }
                    logger.info("Token Response :: " + accessTokenResponseObject);
                    return Optional.ofNullable(accessTokenResponse)
                            .map(AccessTokenResponse::getAccessToken)
                            .filter(token -> !token.isEmpty())
                            .orElseThrow(() -> new SystemApiError(EMPTY_OAUTH_RESPONSE));
                });
    }
}
