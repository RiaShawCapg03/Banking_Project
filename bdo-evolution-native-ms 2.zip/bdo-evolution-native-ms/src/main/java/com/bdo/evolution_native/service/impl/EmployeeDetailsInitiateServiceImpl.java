package com.bdo.evolution_native.service.impl;

import com.bdo.evolution_native.client.EmployeeDetailsClient;
import com.bdo.evolution_native.client.model.employee.*;
import com.bdo.evolution_native.constants.EvolutionConstantUtils;
import com.bdo.evolution_native.model.employee.*;
import com.bdo.evolution_native.service.EmployeeDetailsInitiateService;
import com.bdo.evolution_native.util.MaskUtil;
import com.bdo.evolution_native.util.MethodLogger;
import com.bdo.evolution_native.util.ObjectMapperUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.util.Optional;

/**
 * The type Employee details initiate service.
 */
@Service
public class EmployeeDetailsInitiateServiceImpl implements EmployeeDetailsInitiateService {
    private final Logger logger = LoggerFactory.getLogger(EmployeeDetailsInitiateServiceImpl.class);
    @Autowired
    private MaskUtil maskUtil;

    @Autowired
    private EmployeeDetailsClient employeeDetailsClient;

    /**
     * The type Employee details initiate method.
     */
    @Override
    @MethodLogger
    public Mono<CustomerInquireResponse> initiateEmployeeDetails(
        final CustomerInquireRequest customerSearchInquiryRequest,
        final ServletUriComponentsBuilder servletUriComponentsBuilder) {
        try {
            final String requestObject = ObjectMapperUtil.createObjectMapper(customerSearchInquiryRequest);
            logger.info("MS Request Body: " + requestObject);
        } catch (final JsonProcessingException exception) {
            throw new RuntimeException(exception);
        }
        final CustEmpAddRq custEmpAddRq = mapToCustEmpAddRq(customerSearchInquiryRequest);
        final Mono<CustEmpAddRs> custEmpAddRs = employeeDetailsClient.employeeClient(custEmpAddRq);
        return custEmpAddRs.map(response -> {
            CustomerInquireResponse customerInquireResponse = mapToCustomerInquireResponse(response, servletUriComponentsBuilder);
            try {
                final String responseObject = ObjectMapperUtil.createObjectMapper(customerInquireResponse);
                logger.info("MS Response Body: " + responseObject);
            } catch (final JsonProcessingException exception) {
                throw new RuntimeException(exception);
            }
            return customerInquireResponse;
        });
    }

    @MethodLogger
    private CustEmpAddRq mapToCustEmpAddRq(final CustomerInquireRequest request) {
        final CustomerEmploymentDetails customerEmploymentDetails = request.getCustomerEmploymentDetails();
        final CardAccountDetails cardAccountDetails = customerEmploymentDetails.getCardAccountDetails();
        final CustomerId customerId = customerEmploymentDetails.getCustomerProfileBasic().getCustomerId();
        final EmploymentDetails employmentDetails = customerEmploymentDetails.getEmploymentDetails();
        return CustEmpAddRq.builder()
            .rqUID(RqUID.builder().rqUIDField(customerEmploymentDetails.getRequestId()).build())
            .cardAcctId(CardAcctIdType.builder()
                .acctType(cardAccountDetails.getAccountType())
                .acctId(cardAccountDetails.getAccountId())
                .build())
            .custId(CustIdType.builder().custPermId(customerId.getCustomerNumber()).build())
            .employment(CustEmpRecType.builder()
                .empAddr(null)
                .empStartDt(employmentDetails.getEmploymentStartDate())
                .busEmailAddr(employmentDetails.getBusinessEmailAddress())
                .empIncomeAmt(CustProfBasicTypeEmpIncomeAmt.builder()
                    .amt(employmentDetails.getEmployeeIncomeDetails().getEmployeeIncomeAmount())
                    .build())
                .employerId(employmentDetails.getEmployerId())
                .empPhoneAvailCode(employmentDetails.getEmploymentPhoneAvailableCode())
                .faxNumber(employmentDetails.getFaxNumber())
                .phoneNumber(employmentDetails.getPhoneNumber())
                .empStopDt(employmentDetails.getEmploymentStopDate())
                .empType(employmentDetails.getEmploymentType())
                .jobTitleType(employmentDetails.getJobTitleType())
                .sicCode(employmentDetails.getEmployerSicCode())
                .payrollId(employmentDetails.getPayrollId())
                .build())
            .build();
    }

    @MethodLogger
    private CustomerInquireResponse mapToCustomerInquireResponse(
        final CustEmpAddRs response,
        final ServletUriComponentsBuilder servletUriComponentsBuilder) {

        response.setRqUID(Optional.ofNullable(response.getRqUID())
            .orElseGet(RqUID::new));
        response.setCardAcctId(Optional.ofNullable(response.getCardAcctId())
            .orElseGet(CardAcctIdType::new));
        response.setCustId(Optional.ofNullable(response.getCustId())
            .orElseGet(CustIdType::new));

        // Create and populate the CustomerInquireResponseData object
        final CustomerInquireResponseData customerInquireResponseData = CustomerInquireResponseData.builder()
            .requestId(response.getRqUID().getRqUIDField())
            .cardAccountDetails(CustomerInquireResponseDataCardAccountDetails.builder()
                .accountId(response.getCardAcctId().getAcctId())
                .accountIdMasked(response.getCardAcctId().getAcctIdMasked())
                .accountType(response.getCardAcctId().getAcctType())
                .build())
            .customerId(CustomerInquireResponseDataCustomerId.builder()
                .customerNumber(response.getCustId().getCustPermId())
                .customerNumberMasked(response.getCustId().getCustPermIdMasked())
                .build())
            .build();

        // Create and populate the CustomerInquireResponse object
        return CustomerInquireResponse.builder()
            .data(customerInquireResponseData)
            .meta(Meta.builder()
                .totalPages(EvolutionConstantUtils.ONE)
                .firstAvailableDateTime(EvolutionConstantUtils.EMPTY_STRING)
                .lastAvailableDateTime(EvolutionConstantUtils.EMPTY_STRING)
                .build())
            .links(Links.builder()
                .first(EvolutionConstantUtils.EMPTY_STRING)
                .last(EvolutionConstantUtils.EMPTY_STRING)
                .next(EvolutionConstantUtils.EMPTY_STRING)
                .prev(EvolutionConstantUtils.EMPTY_STRING)
                .self(servletUriComponentsBuilder.build().toString())
                .build())
            .build();
    }
}
