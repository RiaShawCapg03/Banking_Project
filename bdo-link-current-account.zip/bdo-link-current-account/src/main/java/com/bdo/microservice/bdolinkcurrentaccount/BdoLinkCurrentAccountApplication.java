package com.bdo.microservice.bdolinkcurrentaccount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdoLinkCurrentAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdoLinkCurrentAccountApplication.class, args);
	}

}
