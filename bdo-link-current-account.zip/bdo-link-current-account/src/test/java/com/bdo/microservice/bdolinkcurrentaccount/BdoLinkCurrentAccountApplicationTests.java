package com.bdo.microservice.bdolinkcurrentaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdoLinkCurrentAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
