package com.bdo.evolution_native.model.custacctadd;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * AccountResponsePayload
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class AccountResponsePayload {
    @JsonProperty("RequestUID")
    private String requestUID;

    @JsonProperty("SavingAccountFacility")
    private SavingAccountFacilityResponse savingAccountFacility;

}
