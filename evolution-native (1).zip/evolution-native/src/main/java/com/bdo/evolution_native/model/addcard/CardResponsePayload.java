package com.bdo.evolution_native.model.addcard;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CardResponsePayload
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CardResponsePayload {
    @JsonProperty("CustomerReference")
    private CustomerReferenceResponse customerReference;

    @JsonProperty("CardFacility")
    private CardFacilityResponse cardFacility;

}
