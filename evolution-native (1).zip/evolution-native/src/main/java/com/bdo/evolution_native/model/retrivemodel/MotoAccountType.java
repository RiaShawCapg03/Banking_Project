package com.bdo.evolution_native.model.retrivemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * MotoAccountType
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class MotoAccountType {
    @JsonProperty("ExpiryDate")
    private String expiryDate;

}
