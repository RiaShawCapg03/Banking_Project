package com.bdo.evolution_native.model.retrivemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * NationalDetails
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class NationalDetails {
    @JsonProperty("NationalId")
    private String nationalId;

}
