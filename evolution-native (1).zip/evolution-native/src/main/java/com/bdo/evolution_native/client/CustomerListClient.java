package com.bdo.evolution_native.client;

import com.bdo.evolution_native.client.model.customerlist.CustListInqRq;
import com.bdo.evolution_native.client.model.customerlist.CustListInqRs;
import com.bdo.evolution_native.config.WebClientConfig;
import com.bdo.evolution_native.constants.EvolutionConstantUtils;
import com.bdo.evolution_native.exception.EvolutionException;
import com.bdo.evolution_native.exception.SystemApiError;
import com.bdo.evolution_native.util.MethodLogger;
import com.bdo.evolution_native.util.ObjectMapperUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * The type Collateral client.
 */
@Component
@NoArgsConstructor
public class CustomerListClient {
    private final Logger logger = LoggerFactory.getLogger(CustomerListClient.class);
    @Autowired
    private WebClientConfig webClientConfig;
    @Autowired
    private TokenManagerClient tokenManagerClient;
    @Value("${EVOLUTION.BASE_URL}")
    private String baseUrl;
    @Value("${EVOLUTION.TOKEN.PATH}")
    private String tokenPath;
    @Value("${EVOLUTION.TOKEN.PATH_NB}")
    private String tokenPathNb;
    @Value("${EVOLUTION.BASE_URL_NB}")
    private String baseUrlNb;
    @Value("${EVOLUTION.CUSTOMER.LIST.PATH}")
    private String path;
    @Value("${EVOLUTION.TOKEN.CHANNEL_ID_HEADER}")
    private String channelIdHeader;
    @Value("${EVOLUTION.TOKEN.SOURCE_HEADER}")
    private String sourceHeader;
    @Value("${EVOLUTION.TOKEN.CHANNEL_ID_HEADER_NB}")
    private String channelIdHeaderNb;
    @Value("${EVOLUTION.TOKEN.SOURCE_HEADER_NB}")
    private String sourceHeaderNb;

    /**
     * Instantiates a new Collateral client.
     *
     * @param webClientConfig The web client config
     */
    public CustomerListClient(final String baseUrl,
                              final String path,
                              final String tokenPath,
                              final String tokenPathNb,
                              final String channelIdHeader,
                              final String sourceHeader,
                              final String channelIdHeaderNb,
                              final String sourceHeaderNb,
                              final WebClientConfig webClientConfig,
                              final TokenManagerClient tokenManagerClient) {
        this.baseUrl = baseUrl;
        this.path = path;
        this.tokenPath = tokenPath;
        this.tokenPathNb = tokenPathNb;
        this.channelIdHeader = channelIdHeader;
        this.sourceHeader = sourceHeader;
        this.channelIdHeaderNb = channelIdHeaderNb;
        this.sourceHeaderNb = sourceHeaderNb;
        this.webClientConfig = webClientConfig;
        this.tokenManagerClient = tokenManagerClient;
    }

    /**
     * This method calling SOR using WebClient.
     *
     * @return CustomerListClient mono
     */
    @MethodLogger
    public Mono<CustListInqRs> customerClient(final CustListInqRq request, final boolean isNetworkBank) {
        final String variableUrl = isNetworkBank ? baseUrlNb : baseUrl;
        final String variableTokenUrl = isNetworkBank ? tokenPathNb : tokenPath;
        final String variableChannelId = isNetworkBank ? channelIdHeaderNb : channelIdHeader;
        final String variableSourceHeader = isNetworkBank ? sourceHeaderNb : sourceHeader;
        return tokenManagerClient.getAccessToken(variableTokenUrl, variableChannelId, variableSourceHeader)
                .flatMap(token -> {
                    final String requestObject;
                    try {
                        requestObject = ObjectMapperUtil.createObjectMapper(request);
                    } catch (final JsonProcessingException exception) {
                        throw new RuntimeException(exception);
                    }
                    logger.info("SOR: {} {} {} {} {} {}",
                            variableUrl, path,
                            EvolutionConstantUtils.AUTHORIZATION_HEADER,
                            EvolutionConstantUtils.BEARER,
                            token, requestObject);
                    return webClientConfig.getWebClient().post()
                            .uri(variableUrl + path)
                            .accept(MediaType.APPLICATION_JSON)
                            .header(EvolutionConstantUtils.AUTHORIZATION_HEADER,
                                    EvolutionConstantUtils.BEARER
                                            + token)
                            .bodyValue(request)
                            .retrieve()
                            .bodyToMono(CustListInqRs.class)
                            .retryWhen(webClientConfig.retryForServerError())
                            .retryWhen(webClientConfig.retryForConnectionError())
                            .onErrorMap(webClientConfig::handleErrors)
                            .switchIfEmpty(Mono.error(new SystemApiError(EvolutionConstantUtils.EMPTY_SOR_RESPONSE)))
                            .map(this::handleCustListInqRs);
                });
    }

    private CustListInqRs handleCustListInqRs(final CustListInqRs custListInqRs) {
        final String custListInqRsObject;
        try {
            custListInqRsObject = ObjectMapperUtil.createObjectMapper(custListInqRs);
        } catch (final JsonProcessingException exception) {
            throw new RuntimeException(exception);
        }
        logger.info(custListInqRsObject);
        if (!custListInqRs.getStatus()
                .getStatusCode().equals(EvolutionConstantUtils.ZERO)) {
            throw new EvolutionException(custListInqRs.getStatus());
        }
        return custListInqRs;
    }

}
