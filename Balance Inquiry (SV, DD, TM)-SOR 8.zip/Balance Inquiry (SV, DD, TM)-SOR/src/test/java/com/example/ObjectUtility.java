package com.example;

import com.example.model.custacctadd.AcctCustAddRs;
import com.example.util.JsonReader;

import java.lang.reflect.Field;
import java.util.function.Supplier;
import java.util.stream.Stream;

    public class ObjectUtility {

    public static <T> T setDefaultValuesIfNull(T object) {
        if (object == null) {
            return null;
        }

        initializeFieldsIfNull(object);

        return object;
    }

    private static void initializeFieldsIfNull(Object object) {
        Class<?> objectType = object.getClass();
        Field[] fields = objectType.getDeclaredFields();

        for (Field field : fields) {
            field.setAccessible(true);

            try {
                Object fieldValue = field.get(object);
                if (fieldValue == null) {
                    field.set(object, createDefaultInstance(field.getType()));
                } else if (!field.getType().isPrimitive()) {
                    initializeFieldsIfNull(fieldValue);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }

    private static Object createDefaultInstance(Class<?> type) {
        try {
            return type.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static void main(String[] args) {
        AcctCustAddRs acctCustAddRs = new JsonReader<>(AcctCustAddRs.class).loadTestJson("AcctCustAddRs.json");

        System.out.println(ObjectUtility.setDefaultValuesIfNull(acctCustAddRs));
    }
}
