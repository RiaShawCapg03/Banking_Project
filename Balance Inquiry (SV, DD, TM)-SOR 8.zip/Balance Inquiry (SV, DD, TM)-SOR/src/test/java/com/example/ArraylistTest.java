package com.example;

import java.util.ArrayList;

import static org.mockito.Mockito.mock;

public class ArraylistTest {

    public static void main(String[] args) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        ArrayList<Integer> mockedArrayList = mock(ArrayList.class);
        arrayList.add(20000);
        System.out.println(arrayList.get(0));
        mockedArrayList.add(1000);
        System.out.println(mockedArrayList.get(0));
    }

}
