package com.example;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestMain {
    public static void main(String[] args) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(1000);
        System.out.println(arrayList.get(0));  // 1000

        // 1. mocking the class
        ArrayList<Integer> mockList = mock(ArrayList.class);
//        mockList.add(2000);

        // 2. setting its behaviour
        when(mockList.get(anyInt())).thenReturn(2000);

        // 3. perform operation
        System.out.println(mockList.get(0));  // null

    }
}
