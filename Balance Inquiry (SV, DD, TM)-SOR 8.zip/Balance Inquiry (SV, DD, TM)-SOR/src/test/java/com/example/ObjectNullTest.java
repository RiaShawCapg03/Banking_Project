package com.example;

import com.example.model.custacctadd.AcctCustAddRs;
import com.example.util.JsonReader;

public class ObjectNullTest {
    public static void main(String[] args) {
        AcctCustAddRs acctCustAddRs = new JsonReader<>(AcctCustAddRs.class).loadTestJson("AcctCustAddRs.json");

//        System.out.println(ObjectUtility.createEmptyObject(acctCustAddRs));
    }
}
