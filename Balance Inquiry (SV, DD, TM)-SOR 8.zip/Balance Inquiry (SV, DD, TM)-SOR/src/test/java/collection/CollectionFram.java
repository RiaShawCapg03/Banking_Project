package collection;

import java.util.ArrayList;
import java.util.List;

import java.util.*; // space complexity
public class CollectionFram {
    public static void main(String[] args) {
        // initialize an list l, add 3 element {1,2,3}, print the list;
        //  what is collection framework

        List<Integer> l = new ArrayList<>();

        l.add(1);
        l.add(2);
        l.add(3);
        l.set(1,10);

        System.out.println(l);
    }
}
