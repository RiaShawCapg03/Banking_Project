package collection;

import java.util.ArrayList;
import java.util.List;

class People{
    private String name;
    private int age;

    // getter
    public int getAge(){
        return this.age;
    }

    public String getName(){
        return this.name;
    }

    // setter
    public void setName(String name){
        this.name = name;
    }
    public void setAge(int age){
        this.age = age;
    }

    // constructor
    public People(String name, int age){
        this.name = name;
        this.age = age;
    }
    public People(){
        this.name = "blank";
        this.age = 0;
    }

}

public class Problem {
//    Given a list of people with their names and ages,
//    filter out and print the names of people who are adults (aged 18 or older).
    // store it in a new list of adults

    public static void main(String[] args) {
        List<People> listOfPeople = new ArrayList<>();
        listOfPeople.add( new People("Rit",2));
        listOfPeople.add(new People("XYZSVS", 234));
        listOfPeople.add(new People("dd", 34));

        List<People> adults = new ArrayList<>();

        for(People people : listOfPeople){
            if(people.getAge() >= 18){
//                System.out.println(people.getName());
                adults.add(people);
            }
        }

    }
}
