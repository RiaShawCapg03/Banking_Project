package collection;

public class TimeComplexity {
    public static void main(String[] args) {
        //
        int arr[] = {1, 2, 3, 4, 5};

//        int arr2[] = new int[5];

        for (int i = 0; i <= arr.length; i++) {
            if (i == 2) {
                System.out.println(arr[i]);
            }
        }  // 5ms Nms O(N)

        System.out.println(arr[2]); // 1ms O(1)

    }

}
