package collection;

public class Function {
    public static void main(String[] args) {
//        System.out.println(sum(3,5));
        minus(5,3);
    }

    static int sum(int a, int b){
        return a+b;
    }

    // if a is greater than b then only it will return a-b value or else it will return -1
    static int minus(int a, int b) {
       if(a>b){
           return a-b;
       }
       else {
           return -1;
       }
    }

    static void multiply(int a, int b){
        System.out.println(a*b);
    }
}
