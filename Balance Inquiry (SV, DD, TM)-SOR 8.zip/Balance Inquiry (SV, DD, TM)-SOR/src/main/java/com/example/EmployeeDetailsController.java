package com.example;

import com.example.model.Error;
import com.example.model.Status;
import com.example.model.TokenRequest;
import com.example.model.TokenResponse;
import com.example.model.acctlist.AcctListInqRq;
import com.example.model.acctlist.AcctListInqRs;
import com.example.model.addcard.CardAcctAddRq;
import com.example.model.addcard.CardAcctAddRs;
import com.example.model.custacctadd.AcctCustAddRq;
import com.example.model.custacctadd.AcctCustAddRs;
import com.example.model.empDetails.*;
import com.example.model.empDetails.request.CustEmpAddRq;
import com.example.model.initiateModel.CustProfBasicAddRs;
import com.example.model.retrivemodel.CustProfBasicInqRq;
import com.example.model.retrivemodel.CustProfBasicInqRs;
import com.example.util.JsonReader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
public class EmployeeDetailsController {
    @PostMapping("/sor/oauth/token")
    public TokenResponse getLoanBalInq(@RequestHeader(name = "Authorization", required = true) String authorization, @RequestBody TokenRequest request) {
        System.out.println(request);
        RestTemplate template = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", authorization);
        HttpEntity<Object> entity = new HttpEntity<>(request,httpHeaders);
        System.out.println(authorization);
        System.out.println(template.exchange("http://localhost:8100/oauth/token", HttpMethod.POST, entity, TokenResponse.class).getBody());
        return template.exchange("http://localhost:8100/oauth/token", HttpMethod.POST, entity, TokenResponse.class).getBody();

    }
    @PostMapping("/parties/custprofbasic/inq")
    public CustProfBasicInqRs retriveCustomerClient( @RequestHeader(name = "Authorization", required = true) String authorization,
                                                     final CustProfBasicInqRq request)
    {
//        RestTemplate template = new RestTemplate();
//        HttpHeaders httpHeaders = new HttpHeaders();
//        httpHeaders.add("Authorization", authorization);
//        HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
//        Map<String, Object> map = template.exchange("http://localhost:8100/validateUser", HttpMethod.GET, entity, Map.class).getBody();
//        if (!map.containsKey("authenticated") || !(boolean) map.get("authenticated")) {
//            new ResponseEntity<>("Invalid token", HttpStatus.UNAUTHORIZED);
//        }
        JsonReader<CustProfBasicInqRs> mapper1 = new JsonReader<>(CustProfBasicInqRs.class);
        return mapper1.loadTestJson("CustProfBasicInqRs.json");
    }
    @PostMapping("/parties/custprofbasic/add")
    public CustProfBasicAddRs initiateCustomerClient(@RequestHeader(name = "Authorization", required = true) String authorization,
                                                    final CustProfBasicInqRq request)
    {
        JsonReader<CustProfBasicAddRs> mapper1 = new JsonReader<>(CustProfBasicAddRs.class);
        return mapper1.loadTestJson("CustProfBasicAddRs.json");
    }
    @PostMapping("/parties/custemp/add")
    public Response getEmpDetails(@RequestHeader(name = "generated_id", required = false) String generatedId, @RequestBody CustEmpAddRq custEmpAddRq) {
        RqUID rqUID = RqUID.builder()
            .rqUID("3fa85f64-5717-4562-b3fc-2c963f66afa6")
            .build();

        Error error = Error.builder()
            .source("string")
            .errNum("string")
            .errDesc("string")
            .errDtl("string")
            .errField("string")
            .errType("s")
            .errTagName("string")
            .hostErrCode("CU00157")
            .useCode("st")
            .rows(List.of(0))
            .build();

        Status status = Status.builder()
            .statusCode(0)
            .statusDesc("string")
            .supportUID("3fa85f64-5717-4562-b3fc-2c963f66afa6")
            .supportDescription("string")
            .errorCount(0)
            .warningCount(0)
            .errors(List.of(error))
            .warnings(List.of(error))
            .build();

        CardAcctId cardAcctId = CardAcctId.builder()
            .acctId("string")
            .acctIdMasked("string")
            .acctType("string")
            .build();

        CustId custId = CustId.builder()
            .custPermId("string")
            .custPermIdMasked("string")
            .build();

        EmpAddr empAddr = EmpAddr.builder()
            .fullName("string")
            .addr1("string")
            .addr2("string")
            .addr3("string")
            .addr4("string")
            .addr5("string")
            .postalCode("string")
            .zipCode("string")
            .zipSuffix("string")
            .zipRouteNum("st")
            .zipChkDigit("s")
            .postLocaleCode("string")
            .addrCode("string")
            .build();

        EmpIncomeAmt empIncomeAmt = EmpIncomeAmt.builder()
            .amt(0)
            .build();

        Employment employment = Employment.builder()
            .empAddr(empAddr)
            .empStartDt("2023-08-08")
            .busEmailAddr("string")
            .empIncomeAmt(empIncomeAmt)
            .employerId("string")
            .empPhoneAvailCode("string")
            .faxNumber("string")
            .phoneNumber("string")
            .phoneNumberExt("string")
            .empStopDt("2023-08-08")
            .empType("string")
            .jobTitleType("string")
            .sicCode("string")
            .payrollId("string")
            .build();

        // Create the main request object
        Response response = Response.builder()
            .rqUID(rqUID)
            .status(status)
            .cardAcctId(cardAcctId)
            .custId(custId)
            .employment(employment)
            .build();

        return response;
    }



    @PostMapping("/cards/cardacct/add")
    public CardAcctAddRs retriveCustomerClient(@RequestHeader(name = "Authorization", required = true) String authorization,
                                               final CardAcctAddRq request)
    {
        System.out.println(authorization);
        JsonReader<CardAcctAddRs> mapper1 = new JsonReader<>(CardAcctAddRs.class);
        return mapper1.loadTestJson("CardAcctAddRs.json");
    }

    @PostMapping("/customerposition/acctcust/add")
    public AcctCustAddRs custAcctAddClient(@RequestHeader(name = "Authorization", required = true) String authorization,
                                           final AcctCustAddRq request)
    {
        System.out.println(authorization);
        JsonReader<AcctCustAddRs> mapper5 = new JsonReader<>(AcctCustAddRs.class);
        return mapper5.loadTestJson("AcctCustAddRs.json");
    }
    @PostMapping("/customerposition/acctlist/inq")
    public AcctListInqRs getAcctList(@RequestHeader(name = "Authorization", required = true) String authorization,
                                     final AcctListInqRq request)
    {
        System.out.println(request);
        System.out.println(authorization);
        JsonReader<AcctListInqRs> mapper6 = new JsonReader<>(AcctListInqRs.class);
        return mapper6.loadTestJson("AcctListInqRs.json");
    }
}
