package com.example.AuthServer;

import com.example.model.AccessTokenResponse;
import org.springframework.web.bind.annotation.*;

@RestController
public class AuthController {
    @GetMapping("/ms-api/evolution/v1/token")
    public AccessTokenResponse getAccessTocken(@RequestHeader(name = "channelId", required = true) String channelId, @RequestHeader(name = "source", required = true) String source) {
        System.out.println(channelId);
        System.out.println(source);
        return AccessTokenResponse.builder()
                .accessToken("eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyQ2F0ZWdvcnkiOjEsInVzZXJEZXNjcmlwdGlvbiI6IiIsInVzZXJfbmFtZSI6IlNfVUVWT19QVCIsInNjb3BlIjpbInJlYWQiXSwiYXV0aG9yaXR5TGV2ZWwiOjEsImV4cCI6MTY5NzA0NTE3MCwiYnJhbmNoIjoiMDAwMDAiLCJqdGkiOiJIeTJVVUhxcUVNMmw5bUkwMW9qMWFWQXRUY1kiLCJhcHBsaWNhdGlvbk5hbWUiOiJVbmlmaWVkVUlmb3JTaWduYXR1cmUiLCJjbGllbnRfaWQiOiJVbmlmaWVkVUlmb3JTaWduYXR1cmUuY2ZWM0tBNTFmRDFWUnpCNUY2d3RpbVh0N3J4Z1FESDkifQ.p4Ls4APU4v7jpNb7B4Wi4Epww3BaZiW6yzWTNntAf0CyVu5ixmSaViM3z-eAneG2k81Af3IpHex24_0_CTSIoZYpf8y9ogESWwO4zudtC1Hmq9P9nBv5QYInFi224smVZZTDuogRrHuKoKx4PcXcMuK1S1EP1qOG2PVnLeKFt__H0j0kKdGbvidS7XkMILSFQI0mQHrURDTUD_6CSSWe0u4-QPDkR9h7c0DnUJSQwpZlhKRQLwDIdwtj12nDoalZguMzQNBbRLvgmpLHMGjGzo7KpBXnIwZZdpupwPcgAw652MdDQ-hyVaXbPYPLT9bjmt59wz8ZhPbTE8Ec59lE8A")
//                .accessToken(null)
                .channelID("NDBMOB")
                .expiresIn(100)
                .build();
    }

    @GetMapping("/nb/ms-api/evolution/v1/token")
    public AccessTokenResponse getAccessTockenNb(@RequestHeader(name = "channelId", required = true) String channelId, @RequestHeader(name = "source", required = true) String source) {
        System.out.println(channelId);
        System.out.println(source);
        return AccessTokenResponse.builder()
                .accessToken("eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyQ2F0ZWdvcnkiOjEsInVzZXJEZXNjcmlwdGlvbiI6IiIsInVzZXJfbmFtZSI6IlNfVUVWT19QVCIsInNjb3BlIjpbInJlYWQiXSwiYXV0aG9yaXR5TGV2ZWwiOjEsImV4cCI6MTY5NzA0NTE3MCwiYnJhbmNoIjoiMDAwMDAiLCJqdGkiOiJIeTJVVUhxcUVNMmw5bUkwMW9qMWFWQXRUY1kiLCJhcHBsaWNhdGlvbk5hbWUiOiJVbmlmaWVkVUlmb3JTaWduYXR1cmUiLCJjbGllbnRfaWQiOiJVbmlmaWVkVUlmb3JTaWduYXR1cmUuY2ZWM0tBNTFmRDFWUnpCNUY2d3RpbVh0N3J4Z1FESDkifQ.p4Ls4APU4v7jpNb7B4Wi4Epww3BaZiW6yzWTNntAf0CyVu5ixmSaViM3z-eAneG2k81Af3IpHex24_0_CTSIoZYpf8y9ogESWwO4zudtC1Hmq9P9nBv5QYInFi224smVZZTDuogRrHuKoKx4PcXcMuK1S1EP1qOG2PVnLeKFt__H0j0kKdGbvidS7XkMILSFQI0mQHrURDTUD_6CSSWe0u4-QPDkR9h7c0DnUJSQwpZlhKRQLwDIdwtj12nDoalZguMzQNBbRLvgmpLHMGjGzo7KpBXnIwZZdpupwPcgAw652MdDQ-hyVaXbPYPLT9bjmt59wz8ZhPbTE8Ec59lE8A")
//                .accessToken(null)
                .channelID("NDBMOB")
                .expiresIn(100)
                .build();
    }
}
