package com.example.model.loan;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
public class CurAmt {
    private int amt;
    private String curCode;
    private String curConvertRule;
    private int curRate;
}