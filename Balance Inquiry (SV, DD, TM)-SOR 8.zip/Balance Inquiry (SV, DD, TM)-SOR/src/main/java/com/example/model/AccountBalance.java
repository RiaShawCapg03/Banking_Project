package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountBalance {

    @JsonProperty("balType")
    private String balType;

    @JsonProperty("curAmt")
    private Amount curAmt;

}
