package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustBasicDtlType {
    @JsonProperty("custId")
    private CustIdType custId = null;

    @JsonProperty("custType")
    private String custType = null;

    @JsonProperty("custMailCustCode")
    private String custMailCustCode = null;

    @JsonProperty("taxId")
    private SSNIDType taxId = null;

    @JsonProperty("nationalId")
    private NINIDType nationalId = null;

    @JsonProperty("phoneNum")
    private PhoneNumTypeWithExtension phoneNum = null;

    @JsonProperty("birthDt")
    private BirthDateType birthDt = null;

    @JsonProperty("custAddr")
    private NonParsedAddrType custAddr = null;

    @JsonProperty("shortName")
    private String shortName = null;

    @JsonProperty("custStatusCode")
    private String custStatusCode = null;

    @JsonProperty("taxInfoCode")
    private TINIDType taxInfoCode = null;

    @JsonProperty("accessId")
    private String accessId = null;

    @JsonProperty("custDlrDlrGroupFlag")
    private String custDlrDlrGroupFlag = null;

    @JsonProperty("bankId")
    private String bankId = null;

    @JsonProperty("branchId")
    private String branchId = null;

    @JsonProperty("emailAddress")
    private String emailAddress = null;

    @JsonProperty("mobileNoUpdDt")
    private String mobileNoUpdDt = null;

    @JsonProperty("custAcctRelType")
    private String custAcctRelType = null;

    @JsonProperty("emailAddUpdDt")
    private String emailAddUpdDt = null;

    @JsonProperty("citizenCode")
    private String citizenCode = null;

    @JsonProperty("residenceCode")
    private String residenceCode = null;

    @JsonProperty("riskCode")
    private String riskCode = null;

}
