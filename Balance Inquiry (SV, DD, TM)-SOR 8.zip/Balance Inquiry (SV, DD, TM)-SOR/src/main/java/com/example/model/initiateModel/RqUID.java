package com.example.model.initiateModel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * RqUID
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class RqUID {
  @JsonProperty("rqUID")
  private String rqUID;
}