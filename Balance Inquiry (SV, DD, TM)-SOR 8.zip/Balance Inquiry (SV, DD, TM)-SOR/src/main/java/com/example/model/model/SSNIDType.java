package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SSNIDType {
    @JsonProperty("id")
    private String id = null;

    @JsonProperty("idMasked")
    private String idMasked = null;

}
