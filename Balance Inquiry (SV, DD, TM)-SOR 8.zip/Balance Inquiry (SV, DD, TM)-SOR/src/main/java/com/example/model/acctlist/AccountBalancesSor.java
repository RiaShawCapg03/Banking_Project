package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * AccountBalancesSor
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountBalancesSor {

    @JsonProperty("balType")
    private String amountBalanceType;

    @JsonProperty("curAmt")
    private AmountCurrencySor amountCurrency;
}
