package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

/**
 * BalanceInquiryResponse
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BalanceInquiryResponse {

    @JsonProperty("status")
    private StatusType status;

    @JsonProperty("depAcctId")
    private DepartmentAccountId depAcctId;

    @JsonProperty("acctBals")
    private List<AccountBalancesSor> acctBals;

}
