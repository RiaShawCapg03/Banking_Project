package com.example.model.loan;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
public class DepAcctId {
    private String acctType;
    private String acctId;
    private String acctIdMasked;
}