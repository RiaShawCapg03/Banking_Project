package com.example.model.retrivemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CardAcctIdTypeProf4
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CardAcctIdTypeProf4 {
    @JsonProperty("acctId")
    private String acctId;

    @JsonProperty("acctType")
    private String acctType;

    @JsonProperty("bankInfo")
    private BankInfoType bankInfo;

    @JsonProperty("cardHolderFlag")
    private String cardHolderFlag;

    @JsonProperty("ccMotoAcctType")
    private CCMotoAcctType4 ccMotoAcctType;

}
