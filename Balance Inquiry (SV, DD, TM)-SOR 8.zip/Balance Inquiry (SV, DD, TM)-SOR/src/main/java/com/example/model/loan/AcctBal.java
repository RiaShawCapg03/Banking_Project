package com.example.model.loan;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
public class AcctBal {
    private String balType;
    private CurAmt curAmt;
}