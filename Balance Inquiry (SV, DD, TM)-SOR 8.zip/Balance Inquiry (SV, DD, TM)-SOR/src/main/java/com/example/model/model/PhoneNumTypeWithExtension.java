package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PhoneNumTypeWithExtension {
    @JsonProperty("phoneType")
    private String phoneType = null;

    @JsonProperty("phone")
    private String phone = null;

    @JsonProperty("intlDialCode")
    private String intlDialCode = null;

    @JsonProperty("phoneExt")
    private String phoneExt = null;

}
