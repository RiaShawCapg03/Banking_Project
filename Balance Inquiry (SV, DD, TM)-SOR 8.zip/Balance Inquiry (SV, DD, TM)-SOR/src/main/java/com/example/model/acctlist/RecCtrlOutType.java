package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * RecCtrlOutType
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)

public class RecCtrlOutType {
    @JsonProperty("matchedRec")
    private Integer matchedRec;

    @JsonProperty("sentRec")
    private Integer sentRec;

    @JsonProperty("cursor")
    private String cursor;

}
