package com.example.model.loan;

import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Data
@Builder
public class Status {
    private int statusCode;
    private String statusDesc;
    private String supportUID;
    private String supportDescription;
    private int errorCount;
    private int warningCount;
    private List<Error> errors;
    private List<Warning> warnings;
}