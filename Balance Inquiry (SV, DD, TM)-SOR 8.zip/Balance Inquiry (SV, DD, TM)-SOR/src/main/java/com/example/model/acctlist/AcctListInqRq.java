package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigDecimal;

/**
 * AcctListInqRq
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcctListInqRq {
    @JsonProperty("rqUID")
    private RqUID rqUID;

    @JsonProperty("recCtrlIn")
    private RecCtrlInType recCtrlIn;

    @JsonProperty("cardAcctId")
    private CardAcctIdType cardAcctId;

    @JsonProperty("custId")
    private CustIdType custId;

    @JsonProperty("localCurrencyFlag")
    private Boolean localCurrencyFlag;

    @JsonProperty("ddAccountStatus")
    private String ddAccountStatus;

    @JsonProperty("svAccountStatus")
    private String svAccountStatus;

    @JsonProperty("lnAccountStatus")
    private String lnAccountStatus;

    @JsonProperty("tmAccountStatus")
    private String tmAccountStatus;

    @JsonProperty("exAccountStatus")
    private String exAccountStatus;

    @JsonProperty("coAccountStatus")
    private String coAccountStatus;

    @JsonProperty("sdAccountStatus")
    private String sdAccountStatus;

    @JsonProperty("isAccountStatus")
    private String isAccountStatus;

    @JsonProperty("fdAccountStatus")
    private String fdAccountStatus;

    @JsonProperty("brandId")
    private String brandId;

    @JsonProperty("selectCCY")
    private String selectCCY;

    @JsonProperty("ccyFormat")
    private String ccyFormat;

    @JsonProperty("matchWithAccount")
    private BigDecimal matchWithAccount;

    @JsonProperty("incOnlyAppTaking")
    private String incOnlyAppTaking;

}
