package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Generated
@Builder
public class AccessTokenResponse {
    @JsonProperty("access_token")
    private String accessToken;
    @JsonProperty("channelID")
    private String channelID;
    @JsonProperty("expires_in")
    private Integer expiresIn;
}
