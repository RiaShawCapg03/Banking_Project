package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

/**
 * AcctListInqRs
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcctListInqRs {
  @JsonProperty("rqUID")
  private RqUID rqUID = null;

  @JsonProperty("status")
  private StatusType status = null;

  @JsonProperty("recCtrlOut")
  private RecCtrlOutType recCtrlOut = null;

  @JsonProperty("cardAcctId")
  private CardAcctIdType cardAcctId = null;

  @JsonProperty("custId")
  private CustIdType custId = null;

  @JsonProperty("acctSumms")
  private List<AcctSummType> acctSumms = null;

}
