package com.example.model.retrivemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigDecimal;

/**
 * CustProfBasicTypeCashExclusionLimit
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CustProfBasicTypeCashExclusionLimit {
  @JsonProperty("amt")
  private BigDecimal amt;
}