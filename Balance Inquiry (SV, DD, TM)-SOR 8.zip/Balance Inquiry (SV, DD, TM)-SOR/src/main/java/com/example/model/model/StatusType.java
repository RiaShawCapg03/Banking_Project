package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StatusType {
    @JsonProperty("statusCode")
    private Integer statusCode = null;

    @JsonProperty("statusDesc")
    private String statusDesc = null;

    @JsonProperty("supportUID")
    private String supportUID = null;

    @JsonProperty("supportDescription")
    private String supportDescription = null;

    @JsonProperty("errorCount")
    private Integer errorCount = null;

    @JsonProperty("warningCount")
    private Integer warningCount = null;

    @JsonProperty("errors")
    private List<ErrorType> errors = null;

    @JsonProperty("warnings")
    private List<ErrorType> warnings = null;
  
}
