package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.OffsetDateTime;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Time {
  @JsonProperty("hour")
  private Integer hour = null;

  @JsonProperty("minute")
  private Integer minute = null;

  @JsonProperty("second")
  private Integer second = null;

  @JsonProperty("fraction")
  private Integer fraction = null;

  @JsonProperty("utcOffset")
  private OffsetDateTime utcOffset = null;

}
