package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErrorType {
    @JsonProperty("source")
    private String source = null;

    @JsonProperty("errNum")
    private String errNum = null;

    @JsonProperty("errDesc")
    private String errDesc = null;

    @JsonProperty("errDtl")
    private String errDtl = null;

    @JsonProperty("errField")
    private String errField = null;

    @JsonProperty("errType")
    private String errType = null;

    @JsonProperty("errTagName")
    private String errTagName = null;

    @JsonProperty("hostErrCode")
    private String hostErrCode = null;

    @JsonProperty("useCode")
    private String useCode = null;

    @JsonProperty("supportUID")
    private String supportUID = null;

    @JsonProperty("rows")
    private List<Integer> rows = null;
}
