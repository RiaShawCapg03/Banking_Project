package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemoSummType {
  @JsonProperty("memoFlag")
  private Boolean memoFlag = null;

  @JsonProperty("rqMemoFlag")
  private Boolean rqMemoFlag = null;

  @JsonProperty("ticklerFlag")
  private Boolean ticklerFlag = null;

  @JsonProperty("rqTicklerFlag")
  private Boolean rqTicklerFlag = null;

}
