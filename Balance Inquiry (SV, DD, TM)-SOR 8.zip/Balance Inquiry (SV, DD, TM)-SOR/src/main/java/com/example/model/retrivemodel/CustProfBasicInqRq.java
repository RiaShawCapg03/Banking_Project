package com.example.model.retrivemodel;

import com.example.model.empDetails.request.CardAcctIdType;
import com.example.model.empDetails.request.CustIdType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CustProfBasicInqRq
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CustProfBasicInqRq {
    @JsonProperty("rqUID")
    private String rqUID;

    @JsonProperty("cardAcctId")
    private CardAcctIdType cardAcctId;

    @JsonProperty("custId")
    private CustIdType custId;

}
