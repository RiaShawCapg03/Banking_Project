
package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Status {

    @JsonProperty("statusCode")
    private Integer statusCode;
    @JsonProperty("statusDesc")
    private String statusDesc;
    @JsonProperty("supportUID")
    private String supportUID;
    @JsonProperty("supportDescription")
    private String supportDescription;
    @JsonProperty("errorCount")
    private Integer errorCount;
    @JsonProperty("warningCount")
    private Integer warningCount;
    @JsonProperty("errors")
    private List<Error> errors;
    @JsonProperty("warnings")
    private List<Error> warnings;

}
