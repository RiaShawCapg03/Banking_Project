package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NonParsedAddrType {
    @JsonProperty("fullName")
    private String fullName = null;

    @JsonProperty("addr1")
    private String addr1 = null;

    @JsonProperty("addr2")
    private String addr2 = null;

    @JsonProperty("addr3")
    private String addr3 = null;

    @JsonProperty("addr4")
    private String addr4 = null;

    @JsonProperty("addr5")
    private String addr5 = null;

    @JsonProperty("postalCode")
    private String postalCode = null;

    @JsonProperty("zipCode")
    private String zipCode = null;

    @JsonProperty("addrCode")
    private String addrCode = null;

    @JsonProperty("houseName")
    private String houseName = null;

    @JsonProperty("houseNum")
    private String houseNum = null;

    @JsonProperty("street")
    private String street = null;

    @JsonProperty("apartmentNum")
    private String apartmentNum = null;

    @JsonProperty("district")
    private String district = null;

    @JsonProperty("city")
    private String city = null;

    @JsonProperty("stateProv")
    private String stateProv = null;

    @JsonProperty("postLocaleCode")
    private String postLocaleCode = null;

    @JsonProperty("country")
    private String country = null;

    @JsonProperty("countryCode")
    private String countryCode = null;

    @JsonProperty("county")
    private String county = null;

}
