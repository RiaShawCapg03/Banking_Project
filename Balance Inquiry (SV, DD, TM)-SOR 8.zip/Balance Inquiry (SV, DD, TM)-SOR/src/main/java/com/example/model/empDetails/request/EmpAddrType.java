package com.example.model.empDetails.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * EmpAddrType
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class EmpAddrType {
  @JsonProperty("fullName")
  private String fullName = null;

  @JsonProperty("addr1")
  private String addr1 = null;

  @JsonProperty("addr2")
  private String addr2 = null;

  @JsonProperty("addr3")
  private String addr3 = null;

  @JsonProperty("addr4")
  private String addr4 = null;

  @JsonProperty("addr5")
  private String addr5 = null;

  @JsonProperty("postalCode")
  private String postalCode = null;

  @JsonProperty("zipCode")
  private String zipCode = null;

  @JsonProperty("zipSuffix")
  private String zipSuffix = null;

  @JsonProperty("zipRouteNum")
  private String zipRouteNum = null;

  @JsonProperty("zipChkDigit")
  private String zipChkDigit = null;

  @JsonProperty("postLocaleCode")
  private String postLocaleCode = null;

  @JsonProperty("addrCode")
  private String addrCode = null;

}
