package com.example.model.loan;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
public class ExtAcctBal {
    private String extBalType;
    private CurAmt curAmt;
}