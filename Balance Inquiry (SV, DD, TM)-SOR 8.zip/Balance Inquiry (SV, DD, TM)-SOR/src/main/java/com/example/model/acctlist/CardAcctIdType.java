package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CardAcctIdType
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardAcctIdType {
    @JsonProperty("acctId")
    private String acctId;

    @JsonProperty("acctIdMasked")
    private String acctIdMasked;

    @JsonProperty("acctType")
    private String acctType;

}
