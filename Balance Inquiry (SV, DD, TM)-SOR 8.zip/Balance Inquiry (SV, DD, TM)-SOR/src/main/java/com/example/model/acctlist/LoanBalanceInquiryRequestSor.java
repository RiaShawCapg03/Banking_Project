package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * LoanBalanceInquiryRequest
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Generated
public class LoanBalanceInquiryRequestSor {
    @JsonProperty("loanAcctId")
    private LoanAccountId loanAccountId;

    @JsonProperty("incBal")
    private Boolean incBal;

    @JsonProperty("incExtBal")
    private Boolean incExtBal;

}
