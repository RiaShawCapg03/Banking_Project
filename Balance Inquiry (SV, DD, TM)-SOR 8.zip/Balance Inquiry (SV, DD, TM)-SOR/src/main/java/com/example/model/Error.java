
package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.util.List;
@Builder
@AllArgsConstructor
public class Error {

    @JsonProperty("source")
    private String source;
    @JsonProperty("errNum")
    private String errNum;
    @JsonProperty("errDesc")
    private String errDesc;
    @JsonProperty("errDtl")
    private String errDtl;
    @JsonProperty("errField")
    private String errField;
    @JsonProperty("errType")
    private String errType;
    @JsonProperty("errTagName")
    private String errTagName;
    @JsonProperty("hostErrCode")
    private String hostErrCode;
    @JsonProperty("useCode")
    private String useCode;
    @JsonProperty("supportUID")
    private String supportUID;
    @JsonProperty("rows")
    private List<Integer> rows;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Error() {
    }

    /**
     * 
     * @param useCode
     * @param errDesc
     * @param errDtl
     * @param errField
     * @param errNum
     * @param hostErrCode
     * @param supportUID
     * @param errTagName
     * @param source
     */
    public Error(String source, String errNum, String errDesc, String errDtl, String errField, String errTagName, String hostErrCode, String useCode, String supportUID) {
        super();
        this.source = source;
        this.errNum = errNum;
        this.errDesc = errDesc;
        this.errDtl = errDtl;
        this.errField = errField;
        this.errTagName = errTagName;
        this.hostErrCode = hostErrCode;
        this.useCode = useCode;
        this.supportUID = supportUID;
    }

    @JsonProperty("source")
    public String getSource() {
        return source;
    }

    @JsonProperty("source")
    public void setSource(String source) {
        this.source = source;
    }

    public Error withSource(String source) {
        this.source = source;
        return this;
    }

    @JsonProperty("errNum")
    public String getErrNum() {
        return errNum;
    }

    @JsonProperty("errNum")
    public void setErrNum(String errNum) {
        this.errNum = errNum;
    }

    public Error withErrNum(String errNum) {
        this.errNum = errNum;
        return this;
    }

    @JsonProperty("errDesc")
    public String getErrDesc() {
        return errDesc;
    }

    @JsonProperty("errDesc")
    public void setErrDesc(String errDesc) {
        this.errDesc = errDesc;
    }

    public Error withErrDesc(String errDesc) {
        this.errDesc = errDesc;
        return this;
    }

    @JsonProperty("errDtl")
    public String getErrDtl() {
        return errDtl;
    }

    @JsonProperty("errDtl")
    public void setErrDtl(String errDtl) {
        this.errDtl = errDtl;
    }

    public Error withErrDtl(String errDtl) {
        this.errDtl = errDtl;
        return this;
    }

    @JsonProperty("errField")
    public String getErrField() {
        return errField;
    }

    @JsonProperty("errField")
    public void setErrField(String errField) {
        this.errField = errField;
    }

    public Error withErrField(String errField) {
        this.errField = errField;
        return this;
    }

    @JsonProperty("errTagName")
    public String getErrTagName() {
        return errTagName;
    }

    @JsonProperty("errTagName")
    public void setErrTagName(String errTagName) {
        this.errTagName = errTagName;
    }

    public Error withErrTagName(String errTagName) {
        this.errTagName = errTagName;
        return this;
    }

    @JsonProperty("hostErrCode")
    public String getHostErrCode() {
        return hostErrCode;
    }

    @JsonProperty("hostErrCode")
    public void setHostErrCode(String hostErrCode) {
        this.hostErrCode = hostErrCode;
    }

    public Error withHostErrCode(String hostErrCode) {
        this.hostErrCode = hostErrCode;
        return this;
    }

    @JsonProperty("useCode")
    public String getUseCode() {
        return useCode;
    }

    @JsonProperty("useCode")
    public void setUseCode(String useCode) {
        this.useCode = useCode;
    }

    public Error withUseCode(String useCode) {
        this.useCode = useCode;
        return this;
    }

    @JsonProperty("supportUID")
    public String getSupportUID() {
        return supportUID;
    }

    @JsonProperty("supportUID")
    public void setSupportUID(String supportUID) {
        this.supportUID = supportUID;
    }

    public Error withSupportUID(String supportUID) {
        this.supportUID = supportUID;
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Error.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("source");
        sb.append('=');
        sb.append(((this.source == null)?"<null>":this.source));
        sb.append(',');
        sb.append("errNum");
        sb.append('=');
        sb.append(((this.errNum == null)?"<null>":this.errNum));
        sb.append(',');
        sb.append("errDesc");
        sb.append('=');
        sb.append(((this.errDesc == null)?"<null>":this.errDesc));
        sb.append(',');
        sb.append("errDtl");
        sb.append('=');
        sb.append(((this.errDtl == null)?"<null>":this.errDtl));
        sb.append(',');
        sb.append("errField");
        sb.append('=');
        sb.append(((this.errField == null)?"<null>":this.errField));
        sb.append(',');
        sb.append("errTagName");
        sb.append('=');
        sb.append(((this.errTagName == null)?"<null>":this.errTagName));
        sb.append(',');
        sb.append("hostErrCode");
        sb.append('=');
        sb.append(((this.hostErrCode == null)?"<null>":this.hostErrCode));
        sb.append(',');
        sb.append("useCode");
        sb.append('=');
        sb.append(((this.useCode == null)?"<null>":this.useCode));
        sb.append(',');
        sb.append("supportUID");
        sb.append('=');
        sb.append(((this.supportUID == null)?"<null>":this.supportUID));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
