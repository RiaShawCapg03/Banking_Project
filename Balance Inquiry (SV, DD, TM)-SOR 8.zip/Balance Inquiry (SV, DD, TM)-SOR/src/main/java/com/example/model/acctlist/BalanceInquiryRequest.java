package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * BalanceInquiryRequest
 */

/**
 * BalanceInquiryRequest
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BalanceInquiryRequest {
    @JsonProperty("depAcctId")
    private DepartmentAccountId departmentAccountId;

    @JsonProperty("incBal")
    private Boolean incBal;

    @JsonProperty("incExtBal")
    private Boolean incExtBal;

}
