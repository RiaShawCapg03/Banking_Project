package com.example.model.empDetails.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CustEmpAddRq
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CustEmpAddRq {
    @JsonProperty("rqUID")
    private RqUID rqUID = null;

    @JsonProperty("cardAcctId")
    private CardAcctIdType cardAcctId = null;

    @JsonProperty("custId")
    private CustIdType custId = null;

    @JsonProperty("employment")
    private CustEmpRecType2 employment = null;


}
