package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcctSummType {
  @JsonProperty("acctBasic")
  private AcctBasicType acctBasic = null;

  @JsonProperty("relationCode")
  private String relationCode = null;

  @JsonProperty("memoSumm")
  private MemoSummType memoSumm = null;

  @JsonProperty("acctBals")
  private List<AcctBalTypeWithLCYE> acctBals = null;

  @JsonProperty("acctStatCode")
  private String acctStatCode = null;

  @JsonProperty("acctStatCodeDtl")
  private String acctStatCodeDtl = null;

  @JsonProperty("nickname")
  private String nickname = null;

  @JsonProperty("pmtXferFromSupt")
  private Boolean pmtXferFromSupt = null;

  @JsonProperty("xferToSupt")
  private Boolean xferToSupt = null;

  @JsonProperty("acctTitle")
  private String acctTitle = null;

  @JsonProperty("lastTrnDt")
  private LocalDate lastTrnDt = null;

  @JsonProperty("acctLink")
  private AcctLinkType acctLink = null;

  @JsonProperty("overdraftLimitAmt")
  private ExtAcctSummTypeOverdraftLimitAmt overdraftLimitAmt = null;

  @JsonProperty("pmtSchedPeriodCode")
  private String pmtSchedPeriodCode = null;

  @JsonProperty("pmtSchedFreq")
  private Integer pmtSchedFreq = null;

  @JsonProperty("pmtSchedTypeCode")
  private String pmtSchedTypeCode = null;

  @JsonProperty("pmtSchedPct")
  private BigDecimal pmtSchedPct = null;

  @JsonProperty("pmtSchedAmt")
  private ExtAcctSummTypePmtSchedAmt pmtSchedAmt = null;

  @JsonProperty("pmtAmt")
  private ExtAcctSummTypePmtAmt pmtAmt = null;

  @JsonProperty("pastDueFlag")
  private Boolean pastDueFlag = null;

  @JsonProperty("thirdPartyAllowedFlag")
  private Boolean thirdPartyAllowedFlag = null;

  @JsonProperty("tolAmount")
  private ExtAcctSummTypeTolAmount tolAmount = null;

  @JsonProperty("lastATMWithdrawalDt")
  private LocalDate lastATMWithdrawalDt = null;

  @JsonProperty("lastATMWithdrawalTm")
  private Time lastATMWithdrawalTm = null;

  @JsonProperty("lastATMWithdrawalAmt")
  private ExtAcctSummTypeLastATMWithdrawalAmt lastATMWithdrawalAmt = null;

  @JsonProperty("accountRecoveriesStatus")
  private Boolean accountRecoveriesStatus = null;

  @JsonProperty("isaSubsForPeriodAmt")
  private ExtAcctSummTypeIsaSubsForPeriodAmt isaSubsForPeriodAmt = null;

  @JsonProperty("isaUnusedLimitAmt")
  private ExtAcctSummTypeIsaUnusedLimitAmt isaUnusedLimitAmt = null;

  @JsonProperty("isaDepsAllowedUntilDt")
  private LocalDate isaDepsAllowedUntilDt = null;

  @JsonProperty("tolExpiryDt")
  private LocalDate tolExpiryDt = null;

  @JsonProperty("jointAcctFlag")
  private Boolean jointAcctFlag = null;

  @JsonProperty("payOverStatus")
  private String payOverStatus = null;

  @JsonProperty("paymentsPendingTodayAmt")
  private ExtAcctSummTypePaymentsPendingTodayAmt paymentsPendingTodayAmt = null;

  @JsonProperty("avoidChargesAmt")
  private ExtAcctSummTypeAvoidChargesAmt avoidChargesAmt = null;

  @JsonProperty("cardBIN")
  private String cardBIN = null;

}
