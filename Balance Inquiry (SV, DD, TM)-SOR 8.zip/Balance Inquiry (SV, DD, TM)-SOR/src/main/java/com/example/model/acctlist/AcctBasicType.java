package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcctBasicType {
  @JsonProperty("bankAcctId")
  private BankAcctIdType bankAcctId = null;

  @JsonProperty("cardAcctId")
  private CardAcctIdType cardAcctId = null;

  @JsonProperty("aliasBankAcctId")
  private AliasBankAcctIdType aliasBankAcctId = null;

  @JsonProperty("secondaryAliasBankAcctId")
  private AliasBankAcctIdType secondaryAliasBankAcctId = null;

  @JsonProperty("prodId")
  private String prodId = null;

  @JsonProperty("extProdType")
  private String extProdType = null;

  @JsonProperty("branchId")
  private String branchId = null;

  @JsonProperty("openDt")
  private String openDt = null;

  @JsonProperty("matDt")
  private String matDt = null;

  @JsonProperty("isaType")
  private String isaType = null;

  @JsonProperty("isaTransfer")
  private Boolean isaTransfer = null;

  @JsonProperty("isaFixedRate")
  private Boolean isaFixedRate = null;

  @JsonProperty("interestRate")
  private BigDecimal interestRate = null;

  @JsonProperty("authorisedODInterestRate")
  private BigDecimal authorisedODInterestRate = null;

  @JsonProperty("unauthorisedODInterestRate")
  private BigDecimal unauthorisedODInterestRate = null;

}
