package com.example.model.loan;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
public class MockLoanResponse {
    private RqUID rqUID;
    private Status status;
    private DepAcctId depAcctId;
    private CustId custId;
    private CardAcctId cardAcctId;
    private LoanAcctId loanAcctId;
    private AliasBankAcctId aliasBankAcctId;
    private boolean incExtBal;
    private List<AcctBal> acctBals;
    private List<ExtAcctBal> extAcctBal;
}
