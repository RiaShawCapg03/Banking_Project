package com.example.model.retrivemodel;

import com.example.model.empDetails.request.CardAcctIdType;
import com.example.model.empDetails.request.CustIdType;
import com.example.model.empDetails.request.RqUID;
import com.example.model.model.StatusType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CustProfBasicInqRs
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CustProfBasicInqRs {
    @JsonProperty("rqUID")
    private RqUID rqUID;

    @JsonProperty("status")
    private StatusType status;

    @JsonProperty("cardAcctId")
    private CardAcctIdType cardAcctId;

    @JsonProperty("custId")
    private CustIdType custId;

    @JsonProperty("custProfBasic")
    private CustProfBasicType4 custProfBasic;
  
}
