package com.example.model.retrivemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * BirthDateType10
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class BirthDateType10 {
    @JsonProperty("date")
    private String date;

    @JsonProperty("dateMasked")
    private String dateMasked;

}
