package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankAcctIdType {
  @JsonProperty("acctType")
  private String acctType = null;

  @JsonProperty("acctId")
  private String acctId = null;

  @JsonProperty("acctIdMasked")
  private String acctIdMasked = null;

}
