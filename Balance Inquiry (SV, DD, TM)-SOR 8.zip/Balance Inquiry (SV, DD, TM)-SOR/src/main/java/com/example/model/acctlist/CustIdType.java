package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CustIdType
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CustIdType {
    @JsonProperty("custPermId")
    private String custPermId;

    @JsonProperty("custPermIdMasked")
    private String custPermIdMasked;

}
