
package com.example.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Request {

    @JsonProperty("depAcctId")
    private CardAcctId depAcctId;

    @JsonProperty("incBal")
    private boolean incBal;
}