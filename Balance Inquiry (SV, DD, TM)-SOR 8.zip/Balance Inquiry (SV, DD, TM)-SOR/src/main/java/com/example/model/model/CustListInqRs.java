package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustListInqRs {
    @JsonProperty("rqUID")
    private RqUID rqUID = null;

    @JsonProperty("status")
    private StatusType status = null;

    @JsonProperty("recCtrlOut")
    private RecCtrlOutType recCtrlOut = null;

    @JsonProperty("custBasics")
    private List<CustBasicDtlType> custBasics = null;

}
