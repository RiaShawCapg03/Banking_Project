package com.example.model.loan;

public class LoanRequestPayload {
    private RqUID rqUID;
    private DepAcctId depAcctId;
    private CustId custId;
    private CardAcctId cardAcctId;
    private LoanAcctId loanAcctId;
    private AliasBankAcctId aliasBankAcctId;
    private boolean incExtBal;
    private boolean incBal;
}
