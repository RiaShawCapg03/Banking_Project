package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * RecCtrlInType
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RecCtrlInType {
    @JsonProperty("maxRec")
    private Integer maxRec;

    @JsonProperty("cursor")
    private String cursor;

}
