package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * LoanAccountId
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Generated
public class LoanAccountId {
    @JsonProperty("acctId")
    private String acctId;

    @JsonProperty("acctType")
    private String acctType;

}
