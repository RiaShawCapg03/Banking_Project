package com.example.model.loan;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Error {
    private String source;
    private String errNum;
    private String errDesc;
    private String errDtl;
    private String errField;
    private String errType;
    private String errTagName;
    private String hostErrCode;
    private String useCode;
    private String supportUID;
    private List<Integer> rows;
}