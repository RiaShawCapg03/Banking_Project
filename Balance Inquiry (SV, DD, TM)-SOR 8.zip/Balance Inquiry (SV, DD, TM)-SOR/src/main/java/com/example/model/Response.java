
package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Response {

    @JsonProperty("status")
    private Status status;
    @JsonProperty("depAcctId")
    private CardAcctId depAcctId;
    @JsonProperty("acctBals")
    private List<AccountBalance> acctBals;

}
