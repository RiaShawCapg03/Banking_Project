package com.example.model.acctlist;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

/**
 * LoanBalanceInquiryResponseSor
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Generated
public class LoanBalanceInquiryResponseSor {

    @JsonProperty("status")
    private StatusType status;

    @JsonProperty("loanAcctId")
    private LoanAccountId loanAccountId;

    @JsonProperty("acctBals")
    private List<AccountBalancesSor> acctBals;

}
