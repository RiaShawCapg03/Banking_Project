package com.example.model.empDetails.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CustEmpRecType2
 */


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CustEmpRecType2 {
  @JsonProperty("empAddr")
  private EmpAddrType empAddr = null;

  @JsonProperty("empStartDt")
  private String empStartDt = null;

  @JsonProperty("busEmailAddr")
  private String busEmailAddr = null;

  @JsonProperty("empIncomeAmt")
  private CustProfBasicTypeEmpIncomeAmt empIncomeAmt = null;

  @JsonProperty("employerId")
  private String employerId = null;

  @JsonProperty("empPhoneAvailCode")
  private String empPhoneAvailCode = null;

  @JsonProperty("faxNumber")
  private String faxNumber = null;

  @JsonProperty("phoneNumber")
  private String phoneNumber = null;

  @JsonProperty("phoneNumberExt")
  private String phoneNumberExt = null;

  @JsonProperty("empStopDt")
  private String empStopDt = null;

  @JsonProperty("empType")
  private String empType = null;

  @JsonProperty("jobTitleType")
  private String jobTitleType = null;

  @JsonProperty("sicCode")
  private String sicCode = null;

  @JsonProperty("payrollId")
  private String payrollId = null;


}
