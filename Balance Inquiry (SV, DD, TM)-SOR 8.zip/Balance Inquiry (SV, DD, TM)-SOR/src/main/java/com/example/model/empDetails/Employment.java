package com.example.model.empDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Employment {
    private EmpAddr empAddr;
    private String empStartDt;
    private String busEmailAddr;
    private EmpIncomeAmt empIncomeAmt;
    private String employerId;
    private String empPhoneAvailCode;
    private String faxNumber;
    private String phoneNumber;
    private String phoneNumberExt;
    private String empStopDt;
    private String empType;
    private String jobTitleType;
    private String sicCode;
    private String payrollId;
}