package com.example.model.initiateModel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * CCMotoAcctType
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class CCMotoAcctType {
  @JsonProperty("expDt")
  private String expDt;
}