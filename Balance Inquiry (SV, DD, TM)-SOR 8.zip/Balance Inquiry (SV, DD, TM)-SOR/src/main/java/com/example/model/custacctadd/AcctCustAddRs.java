package com.example.model.custacctadd;

import com.example.model.model.RqUID;
import com.example.model.model.StatusType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * AcctCustAddRs
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class AcctCustAddRs {
  @JsonProperty("rqUID")
  private RqUID rqUID = null;

  @JsonProperty("status")
  private StatusType status = null;
}
