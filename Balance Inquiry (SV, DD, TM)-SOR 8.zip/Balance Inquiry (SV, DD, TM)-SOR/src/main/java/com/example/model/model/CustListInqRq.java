package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustListInqRq {
    @JsonProperty("rqUID")
    private RqUID rqUID = null;

    @JsonProperty("recCtrlIn")
    private RecCtrlInType recCtrlIn = null;

    @JsonProperty("customerType")
    private String customerType = null;

    @JsonProperty("searchType")
    private String searchType = null;

    @JsonProperty("searchValue")
    private String searchValue = null;

    @JsonProperty("birthDt")
    private String birthDt = null;

    @JsonProperty("aliasBankAcctId")
    private AliasBankAcctIdType aliasBankAcctId = null;

    @JsonProperty("postalCode")
    private String postalCode = null;

    @JsonProperty("accessCode")
    private String accessCode = null;

    @JsonProperty("debitCardNumber")
    private String debitCardNumber = null;

    @JsonProperty("taxId")
    private String taxId = null;

    @JsonProperty("shortName")
    private String shortName = null;

    @JsonProperty("bankAcctId")
    private BankAcctIdType bankAcctId = null;

    @JsonProperty("nationalId")
    private String nationalId = null;

    @JsonProperty("phoneNum")
    private PhoneNumTypeWithExtension phoneNum = null;

    @JsonProperty("userKey")
    private String userKey = null;

    @JsonProperty("taxInfoCode")
    private String taxInfoCode = null;

    @JsonProperty("custId")
    private String custId = null;

    @JsonProperty("firstName")
    private String firstName = null;

    @JsonProperty("secondName")
    private String secondName = null;

    @JsonProperty("lastName")
    private String lastName = null;

    @JsonProperty("businessName")
    private String businessName = null;

    @JsonProperty("mobileNum")
    private String mobileNum = null;

    @JsonProperty("eMailAddress")
    private String eMailAddress = null;

    @JsonProperty("compliment")
    private String compliment = null;

    @JsonProperty("incDealerCode")
    private String incDealerCode = null;

    @JsonProperty("searchOption")
    private String searchOption = null;

}
