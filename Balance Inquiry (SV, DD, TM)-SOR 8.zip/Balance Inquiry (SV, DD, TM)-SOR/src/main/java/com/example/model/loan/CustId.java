package com.example.model.loan;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustId {
    private String custPermId;
    private String custPermIdMasked;
}