package com.example.model.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BankAcctIdType {
  @JsonProperty("acctType")
  private String acctType = null;

  @JsonProperty("acctId")
  private String acctId = null;

  @JsonProperty("acctIdMasked")
  private String acctIdMasked = null;
  
}
