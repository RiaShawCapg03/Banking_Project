package com.example.model.empDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmpAddr {
    private String fullName;
    private String addr1;
    private String addr2;
    private String addr3;
    private String addr4;
    private String addr5;
    private String postalCode;
    private String zipCode;
    private String zipSuffix;
    private String zipRouteNum;
    private String zipChkDigit;
    private String postLocaleCode;
    private String addrCode;
}