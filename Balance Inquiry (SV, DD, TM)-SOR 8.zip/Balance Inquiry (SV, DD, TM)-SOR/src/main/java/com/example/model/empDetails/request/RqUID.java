package com.example.model.empDetails.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * RqUID
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Generated
public class RqUID {
    @JsonProperty("rqUID")
    private String rqUID = null;


}
