package com.example.soap;
import lombok.Data;

import javax.xml.bind.annotation.*;

@XmlRootElement(name = "getOwnAccounts", namespace = "http://obsecws.bdo.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class GetOwnAccountsRequest {
    @XmlElement(name = "clientId")
    private String clientId;

    @XmlElement(name = "loginId")
    private String loginId;

    @XmlElement(name = "sessionId")
    private String sessionId;

}
