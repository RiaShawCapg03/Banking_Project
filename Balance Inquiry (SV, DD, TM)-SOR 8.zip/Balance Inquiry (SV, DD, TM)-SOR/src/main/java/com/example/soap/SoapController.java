package com.example.soap;

import com.example.soap.GetOwnAccountsBody;
import com.example.soap.GetOwnAccountsEnvelope;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SoapController {

    @PostMapping(value = "/soapEndpoint", produces = "application/xml")
    public GetOwnAccountsEnvelope handleSOAPRequest(@RequestBody GetOwnAccountsEnvelope soapEnvelope) {
        // Extracting request from the envelope
        GetOwnAccountsBody body = soapEnvelope.getBody();
        System.out.println(body.getRequest().getClientId());
        System.out.println(body.toString());
//        String response = null;

            return soapEnvelope;
    }

    // Method to generate the SOAP response
    private String generateSOAPResponse(String clientId, String loginId, String sessionId) {
        // Replace this with the logic to generate your SOAP response based on the request data
        // Construct your SOAP response using the received parameters

        // For example:
        String soapResponse = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
            "<soapenv:Body>" +
            "<YourResponseElement>Response Data Here</YourResponseElement>" +
            "</soapenv:Body>" +
            "</soapenv:Envelope>";

        return soapResponse;
    }

}
