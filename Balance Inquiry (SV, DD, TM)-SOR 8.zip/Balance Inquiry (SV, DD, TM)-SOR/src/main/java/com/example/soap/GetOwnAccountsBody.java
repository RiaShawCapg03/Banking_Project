package com.example.soap;

import lombok.Data;

import javax.xml.bind.annotation.*;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class GetOwnAccountsBody {

    @XmlElement(name = "getOwnAccounts", namespace = "http://obsecws.bdo.com/")
    private GetOwnAccountsRequest request;

}