package com.example.soap;
import lombok.Data;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
class GetOwnAccountsHeader {

    @XmlElement(name = "AdditionalHeader", namespace = "http://obsecws.bdo.com/")
    private AdditionalHeader additionalHeader;


}