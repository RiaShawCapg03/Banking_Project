package com.example.service;
import com.example.model.AccountBalance;
import com.example.model.Amount;
import com.example.model.Request;
import com.example.model.Response;
import com.example.model.Status;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerInqService {

    public Response getResponse(Request request){
        Status status = new Status(0, "successful", null,null, null, null, null, null);
        List<AccountBalance> balances = new ArrayList<>();
        balances.add(new AccountBalance("Current", new Amount(245.879, "Cur")));
//        balances.add(new AccountBalance("Avail", new Amount(new BigDecimal(18396963.29), "Ava")));
//        balances.add(new AccountBalance("PastDue", new Amount(new BigDecimal(18396963.29), "Pas")));
//        balances.add(new AccountBalance("Ledger", new Amount(new BigDecimal(18396963), "Led")));
//        balances.add(new AccountBalance("MinLedger", new Amount(new BigDecimal(18396963.29), "Min")));

        return new Response(status,request.getDepAcctId(),balances);
    }

}
