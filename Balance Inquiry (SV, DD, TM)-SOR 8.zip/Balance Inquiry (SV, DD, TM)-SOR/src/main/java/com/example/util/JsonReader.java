package com.example.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.InputStreamReader;

/**
 * The type Json reader.
 *
 * @param <T> the type parameter
 */
@Slf4j
public class JsonReader<T> {
    private final Class<T> model;

    /**
     * Instantiates a new Json reader.
     *
     * @param model the model
     */
    public JsonReader(Class<T> model) {
        this.model = model;
    }

    /**
     * Load test json t.
     *
     * @param fileName the file name
     * @return the t
     */
    public T loadTestJson(String fileName) {

        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            final String content = IOUtils.toString(new InputStreamReader(this.getClass().getClassLoader()
                    .getResourceAsStream(fileName)));
//            log.info("content {}", content);
            return mapper.readValue(content, this.model);
        } catch (final Exception exp) {
            log.error("Error Reading the file {} with error {}", fileName, ExceptionUtils.getStackTrace(exp));
            return null;
        }
    }
}
